using N1;
using N2;
using N3;
using N4;
using System;

namespace N0
{
public class C0
{
public static void M1()
{
C3.M75();
C4.M81();
C2.M56();
C0.M5();
C0.M2();
}
public static void M2()
{
C3.M63();
C2.M49();
C0.M3();
}
public static void M3()
{
C0.M10();
C0.M4();
}
public static void M4()
{
C3.M71();
C4.M92();
C1.M25();
C4.M85();
C0.M5();
}
public static void M5()
{
C1.M31();
C3.M75();
C0.M14();
C0.M6();
}
public static void M6()
{
C2.M47();
C3.M72();
C0.M7();
}
public static void M7()
{
C1.M21();
C0.M8();
}
public static void M8()
{
C0.M9();
}
public static void M9()
{
C4.M95();
C1.M25();
C0.M11();
C4.M93();
C0.M10();
}
public static void M10()
{
C3.M74();
C1.M28();
C0.M5();
C3.M77();
C0.M11();
}
public static void M11()
{
C3.M63();
C2.M56();
C0.M12();
}
public static void M12()
{
C2.M50();
C4.M94();
C0.M13();
}
public static void M13()
{
C1.M28();
C3.M74();
C4.M93();
C3.M67();
C0.M14();
}
public static void M14()
{
C2.M50();
C2.M45();
C1.M38();
C0.M11();
C0.M15();
}
public static void M15()
{
C4.M91();
C0.M9();
C0.M16();
}
public static void M16()
{
C2.M60();
C1.M37();
C4.M95();
C0.M17();
}
public static void M17()
{
C3.M66();
C1.M25();
C0.M18();
}
public static void M18()
{
C0.M16();
C0.M19();
}
public static void M19()
{
C4.M96();
C0.M20();
}
public static void M20()
{
C0.M20();
C0.M8();
C1.M24();
C1.M21();
}
public static void Main(string[] args)
{
C0.M1();
}
}
}
