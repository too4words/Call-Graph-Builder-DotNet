namespace Temporary
{
    public class C0
    {
        public static void N0()
        {
            C0.N2();
            C0.N11();
            C0.N15();
            C0.N36();
            C0.N40();
            C0.N51();
            C0.N81();
            C0.N83();
            C0.N89();
        }

        public static void N1()
        {
            C0.N3();
            C0.N21();
            C0.N36();
            C0.N37();
            C0.N42();
            C0.N74();
            C0.N80();
            C0.N91();
            C0.N93();
        }

        public static void N2()
        {
            C0.N0();
            C0.N3();
            C0.N6();
            C0.N14();
            C0.N29();
            C0.N33();
            C0.N36();
            C0.N44();
            C0.N49();
            C0.N59();
            C0.N81();
            C0.N88();
        }

        public static void N3()
        {
            C0.N7();
            C0.N9();
            C0.N12();
            C0.N23();
            C0.N31();
            C0.N39();
            C0.N44();
            C0.N48();
            C0.N59();
            C0.N61();
            C0.N71();
            C0.N75();
            C0.N88();
        }

        public static void N4()
        {
            C0.N25();
            C0.N58();
            C0.N60();
            C0.N61();
            C0.N74();
            C0.N92();
            C0.N98();
        }

        public static void N5()
        {
            C0.N0();
            C0.N2();
            C0.N14();
            C0.N17();
            C0.N32();
            C0.N36();
            C0.N97();
        }

        public static void N6()
        {
            C0.N29();
            C0.N35();
            C0.N70();
            C0.N72();
            C0.N77();
            C0.N92();
        }

        public static void N7()
        {
            C0.N4();
            C0.N16();
            C0.N24();
            C0.N28();
            C0.N38();
            C0.N65();
            C0.N76();
            C0.N81();
        }

        public static void N8()
        {
            C0.N4();
            C0.N12();
            C0.N21();
            C0.N25();
            C0.N36();
            C0.N59();
            C0.N62();
            C0.N66();
            C0.N73();
            C0.N80();
            C0.N82();
            C0.N89();
        }

        public static void N9()
        {
            C0.N2();
            C0.N12();
            C0.N20();
            C0.N21();
            C0.N59();
            C0.N61();
            C0.N70();
            C0.N75();
            C0.N91();
        }

        public static void N10()
        {
            C0.N1();
            C0.N8();
            C0.N22();
            C0.N32();
            C0.N44();
            C0.N55();
            C0.N56();
            C0.N75();
            C0.N83();
            C0.N94();
        }

        public static void N11()
        {
            C0.N16();
            C0.N19();
            C0.N31();
            C0.N83();
            C0.N89();
        }

        public static void N12()
        {
            C0.N21();
            C0.N34();
            C0.N35();
            C0.N38();
            C0.N47();
            C0.N53();
            C0.N56();
            C0.N57();
            C0.N66();
            C0.N76();
            C0.N87();
            C0.N91();
            C0.N98();
        }

        public static void N13()
        {
            C0.N1();
            C0.N2();
            C0.N17();
            C0.N24();
            C0.N35();
            C0.N44();
            C0.N45();
            C0.N49();
            C0.N53();
            C0.N69();
            C0.N71();
            C0.N74();
            C0.N96();
            C0.N97();
        }

        public static void N14()
        {
            C0.N5();
            C0.N52();
            C0.N53();
            C0.N55();
            C0.N61();
            C0.N77();
            C0.N78();
            C0.N83();
        }

        public static void N15()
        {
            C0.N8();
            C0.N18();
            C0.N22();
            C0.N46();
            C0.N51();
            C0.N53();
            C0.N73();
        }

        public static void N16()
        {
            C0.N5();
            C0.N13();
            C0.N16();
            C0.N51();
            C0.N52();
            C0.N60();
            C0.N71();
            C0.N72();
            C0.N88();
        }

        public static void N17()
        {
            C0.N14();
            C0.N16();
            C0.N20();
            C0.N28();
            C0.N33();
            C0.N40();
            C0.N42();
            C0.N44();
            C0.N46();
            C0.N49();
            C0.N67();
            C0.N71();
            C0.N76();
            C0.N87();
            C0.N88();
        }

        public static void N18()
        {
            C0.N7();
            C0.N9();
            C0.N22();
            C0.N37();
            C0.N43();
            C0.N50();
            C0.N62();
            C0.N63();
            C0.N70();
            C0.N76();
            C0.N83();
            C0.N96();
        }

        public static void N19()
        {
            C0.N7();
            C0.N16();
            C0.N30();
            C0.N47();
            C0.N51();
            C0.N56();
            C0.N98();
        }

        public static void N20()
        {
            C0.N4();
            C0.N7();
            C0.N13();
            C0.N31();
            C0.N38();
            C0.N48();
            C0.N50();
        }

        public static void N21()
        {
            C0.N1();
            C0.N3();
            C0.N4();
            C0.N13();
            C0.N19();
            C0.N61();
            C0.N64();
        }

        public static void N22()
        {
            C0.N3();
            C0.N9();
            C0.N10();
            C0.N15();
            C0.N34();
            C0.N54();
            C0.N65();
            C0.N77();
            C0.N85();
            C0.N90();
            C0.N93();
        }

        public static void N23()
        {
            C0.N23();
            C0.N35();
            C0.N59();
            C0.N63();
            C0.N79();
            C0.N86();
        }

        public static void N24()
        {
            C0.N6();
            C0.N17();
            C0.N18();
            C0.N28();
            C0.N32();
            C0.N50();
            C0.N51();
            C0.N67();
            C0.N74();
            C0.N75();
            C0.N78();
            C0.N82();
        }

        public static void N25()
        {
            C0.N0();
            C0.N5();
            C0.N11();
            C0.N22();
            C0.N24();
            C0.N29();
            C0.N39();
            C0.N42();
            C0.N65();
            C0.N68();
            C0.N70();
            C0.N80();
            C0.N85();
            C0.N94();
        }

        public static void N26()
        {
            C0.N6();
            C0.N15();
            C0.N19();
            C0.N20();
            C0.N33();
            C0.N34();
            C0.N36();
            C0.N87();
            C0.N88();
        }

        public static void N27()
        {
            C0.N11();
            C0.N17();
            C0.N30();
            C0.N43();
            C0.N62();
            C0.N72();
            C0.N88();
            C0.N92();
            C0.N94();
        }

        public static void N28()
        {
            C0.N16();
            C0.N17();
            C0.N57();
            C0.N80();
            C0.N85();
            C0.N89();
            C0.N96();
            C0.N97();
        }

        public static void N29()
        {
            C0.N10();
            C0.N12();
            C0.N16();
            C0.N37();
            C0.N45();
            C0.N49();
            C0.N58();
            C0.N71();
            C0.N96();
        }

        public static void N30()
        {
            C0.N8();
            C0.N20();
            C0.N24();
            C0.N32();
            C0.N34();
            C0.N36();
            C0.N39();
            C0.N45();
            C0.N48();
            C0.N56();
            C0.N63();
            C0.N82();
            C0.N85();
        }

        public static void N31()
        {
            C0.N9();
            C0.N22();
            C0.N26();
            C0.N32();
            C0.N59();
            C0.N82();
            C0.N84();
            C0.N94();
        }

        public static void N32()
        {
            C0.N24();
            C0.N27();
            C0.N39();
            C0.N41();
            C0.N43();
            C0.N65();
        }

        public static void N33()
        {
            C0.N10();
            C0.N21();
            C0.N40();
            C0.N55();
            C0.N60();
            C0.N65();
            C0.N70();
            C0.N86();
            C0.N92();
        }

        public static void N34()
        {
            C0.N13();
            C0.N21();
            C0.N35();
            C0.N73();
            C0.N82();
            C0.N86();
            C0.N92();
            C0.N98();
        }

        public static void N35()
        {
            C0.N0();
            C0.N6();
            C0.N29();
            C0.N46();
            C0.N56();
            C0.N58();
            C0.N59();
            C0.N79();
            C0.N82();
            C0.N87();
        }

        public static void N36()
        {
            C0.N3();
            C0.N14();
            C0.N22();
            C0.N32();
            C0.N34();
            C0.N35();
            C0.N58();
            C0.N63();
            C0.N68();
            C0.N73();
            C0.N84();
            C0.N89();
        }

        public static void N37()
        {
            C0.N5();
            C0.N11();
            C0.N17();
            C0.N19();
            C0.N25();
            C0.N30();
            C0.N34();
            C0.N35();
            C0.N36();
            C0.N48();
            C0.N55();
            C0.N67();
            C0.N68();
            C0.N73();
            C0.N74();
            C0.N96();
        }

        public static void N38()
        {
            C0.N25();
            C0.N28();
            C0.N30();
            C0.N42();
            C0.N44();
            C0.N60();
            C0.N63();
            C0.N76();
            C0.N86();
        }

        public static void N39()
        {
            C0.N0();
            C0.N5();
            C0.N26();
            C0.N34();
            C0.N35();
            C0.N40();
            C0.N52();
            C0.N60();
            C0.N65();
            C0.N67();
            C0.N76();
            C0.N80();
            C0.N82();
            C0.N88();
            C0.N90();
            C0.N95();
            C0.N96();
            C0.N98();
        }

        public static void N40()
        {
            C0.N0();
            C0.N14();
            C0.N19();
            C0.N42();
            C0.N50();
            C0.N52();
            C0.N82();
            C0.N83();
            C0.N93();
        }

        public static void N41()
        {
            C0.N9();
            C0.N16();
            C0.N20();
            C0.N22();
            C0.N39();
            C0.N40();
            C0.N41();
            C0.N43();
            C0.N74();
            C0.N78();
            C0.N79();
            C0.N81();
            C0.N96();
        }

        public static void N42()
        {
            C0.N9();
            C0.N11();
            C0.N14();
            C0.N18();
            C0.N39();
            C0.N40();
            C0.N57();
            C0.N58();
            C0.N60();
            C0.N70();
            C0.N73();
            C0.N75();
            C0.N86();
            C0.N94();
        }

        public static void N43()
        {
            C0.N1();
            C0.N4();
            C0.N19();
            C0.N27();
            C0.N33();
            C0.N55();
            C0.N66();
            C0.N79();
            C0.N88();
            C0.N89();
            C0.N93();
        }

        public static void N44()
        {
            C0.N12();
            C0.N26();
            C0.N33();
            C0.N41();
            C0.N48();
            C0.N60();
            C0.N73();
            C0.N81();
            C0.N85();
            C0.N90();
        }

        public static void N45()
        {
            C0.N20();
            C0.N25();
            C0.N34();
            C0.N41();
            C0.N51();
            C0.N57();
            C0.N72();
            C0.N73();
            C0.N74();
            C0.N89();
            C0.N90();
            C0.N94();
        }

        public static void N46()
        {
            C0.N5();
            C0.N8();
            C0.N10();
            C0.N19();
            C0.N23();
            C0.N27();
            C0.N46();
            C0.N48();
            C0.N57();
            C0.N66();
            C0.N87();
            C0.N94();
            C0.N96();
        }

        public static void N47()
        {
            C0.N3();
            C0.N31();
            C0.N54();
            C0.N66();
            C0.N68();
            C0.N69();
            C0.N86();
            C0.N93();
            C0.N94();
        }

        public static void N48()
        {
            C0.N10();
            C0.N18();
            C0.N20();
            C0.N23();
            C0.N24();
            C0.N26();
            C0.N32();
            C0.N33();
            C0.N57();
            C0.N62();
            C0.N66();
            C0.N68();
            C0.N75();
            C0.N77();
            C0.N86();
            C0.N91();
        }

        public static void N49()
        {
            C0.N4();
            C0.N47();
            C0.N52();
            C0.N63();
            C0.N79();
            C0.N80();
            C0.N89();
            C0.N95();
        }

        public static void N50()
        {
            C0.N2();
            C0.N8();
            C0.N9();
            C0.N11();
            C0.N17();
            C0.N22();
            C0.N33();
            C0.N47();
            C0.N57();
            C0.N76();
            C0.N83();
            C0.N87();
            C0.N95();
        }

        public static void N51()
        {
            C0.N6();
            C0.N11();
            C0.N43();
            C0.N46();
            C0.N48();
            C0.N53();
            C0.N57();
            C0.N60();
            C0.N64();
            C0.N96();
        }

        public static void N52()
        {
            C0.N3();
            C0.N6();
            C0.N18();
            C0.N21();
            C0.N38();
            C0.N41();
            C0.N42();
            C0.N43();
            C0.N46();
            C0.N53();
            C0.N54();
            C0.N62();
            C0.N63();
            C0.N67();
            C0.N88();
            C0.N89();
        }

        public static void N53()
        {
            C0.N20();
            C0.N27();
            C0.N30();
            C0.N31();
            C0.N35();
            C0.N41();
            C0.N56();
            C0.N58();
            C0.N77();
        }

        public static void N54()
        {
            C0.N6();
            C0.N37();
            C0.N56();
            C0.N58();
            C0.N77();
        }

        public static void N55()
        {
            C0.N5();
            C0.N13();
            C0.N15();
            C0.N39();
            C0.N42();
            C0.N52();
            C0.N55();
            C0.N57();
            C0.N62();
            C0.N74();
        }

        public static void N56()
        {
            C0.N1();
            C0.N2();
            C0.N13();
            C0.N18();
            C0.N29();
            C0.N30();
            C0.N31();
            C0.N33();
            C0.N43();
            C0.N47();
            C0.N49();
            C0.N54();
            C0.N59();
            C0.N67();
            C0.N75();
            C0.N88();
            C0.N89();
            C0.N91();
            C0.N93();
            C0.N98();
        }

        public static void N57()
        {
            C0.N37();
            C0.N47();
            C0.N52();
            C0.N77();
            C0.N91();
            C0.N92();
        }

        public static void N58()
        {
            C0.N14();
            C0.N29();
            C0.N35();
            C0.N49();
            C0.N52();
            C0.N72();
            C0.N93();
            C0.N97();
        }

        public static void N59()
        {
            C0.N6();
            C0.N13();
            C0.N33();
            C0.N40();
            C0.N43();
            C0.N52();
            C0.N69();
            C0.N81();
            C0.N87();
            C0.N90();
        }

        public static void N60()
        {
            C0.N2();
            C0.N8();
            C0.N9();
            C0.N22();
            C0.N23();
            C0.N28();
            C0.N47();
            C0.N54();
            C0.N64();
            C0.N67();
            C0.N74();
            C0.N84();
            C0.N91();
            C0.N93();
            C0.N95();
        }

        public static void N61()
        {
            C0.N21();
            C0.N29();
            C0.N55();
            C0.N64();
            C0.N85();
            C0.N92();
        }

        public static void N62()
        {
            C0.N0();
            C0.N4();
            C0.N34();
            C0.N45();
            C0.N54();
            C0.N63();
            C0.N69();
            C0.N78();
            C0.N85();
            C0.N93();
        }

        public static void N63()
        {
            C0.N12();
            C0.N37();
            C0.N51();
            C0.N95();
        }

        public static void N64()
        {
            C0.N3();
            C0.N18();
            C0.N23();
            C0.N29();
            C0.N30();
            C0.N48();
            C0.N65();
            C0.N66();
            C0.N69();
            C0.N71();
            C0.N79();
            C0.N86();
            C0.N95();
            C0.N97();
        }

        public static void N65()
        {
            C0.N2();
            C0.N12();
            C0.N13();
            C0.N16();
            C0.N28();
            C0.N45();
            C0.N47();
            C0.N64();
            C0.N65();
            C0.N71();
            C0.N78();
            C0.N82();
            C0.N85();
            C0.N98();
        }

        public static void N66()
        {
            C0.N2();
            C0.N7();
            C0.N15();
            C0.N19();
            C0.N39();
            C0.N43();
            C0.N51();
            C0.N59();
            C0.N73();
            C0.N84();
            C0.N90();
        }

        public static void N67()
        {
            C0.N7();
            C0.N15();
            C0.N17();
            C0.N27();
            C0.N48();
            C0.N54();
            C0.N56();
            C0.N59();
            C0.N62();
            C0.N66();
            C0.N80();
            C0.N89();
            C0.N96();
            C0.N98();
        }

        public static void N68()
        {
            C0.N2();
            C0.N3();
            C0.N15();
            C0.N18();
            C0.N37();
            C0.N48();
            C0.N58();
            C0.N78();
            C0.N80();
            C0.N92();
        }

        public static void N69()
        {
            C0.N10();
            C0.N23();
            C0.N38();
            C0.N42();
            C0.N64();
            C0.N72();
            C0.N92();
        }

        public static void N70()
        {
            C0.N6();
            C0.N9();
            C0.N21();
            C0.N26();
            C0.N31();
            C0.N38();
            C0.N39();
            C0.N41();
            C0.N42();
            C0.N44();
            C0.N49();
            C0.N56();
            C0.N79();
            C0.N92();
            C0.N96();
        }

        public static void N71()
        {
            C0.N4();
            C0.N10();
            C0.N49();
            C0.N50();
            C0.N53();
            C0.N55();
            C0.N62();
            C0.N81();
        }

        public static void N72()
        {
            C0.N0();
            C0.N17();
            C0.N30();
            C0.N44();
            C0.N45();
            C0.N52();
            C0.N54();
            C0.N59();
            C0.N87();
        }

        public static void N73()
        {
            C0.N9();
            C0.N11();
            C0.N29();
            C0.N54();
            C0.N71();
            C0.N79();
            C0.N95();
        }

        public static void N74()
        {
            C0.N8();
            C0.N11();
            C0.N34();
            C0.N40();
            C0.N45();
            C0.N58();
            C0.N60();
            C0.N62();
            C0.N71();
            C0.N75();
            C0.N84();
            C0.N90();
            C0.N91();
        }

        public static void N75()
        {
            C0.N23();
            C0.N26();
            C0.N28();
            C0.N42();
            C0.N44();
            C0.N50();
            C0.N95();
        }

        public static void N76()
        {
            C0.N4();
            C0.N20();
            C0.N25();
            C0.N29();
            C0.N62();
            C0.N64();
            C0.N66();
            C0.N72();
            C0.N81();
        }

        public static void N77()
        {
            C0.N1();
            C0.N50();
            C0.N53();
            C0.N60();
            C0.N68();
            C0.N73();
            C0.N80();
            C0.N82();
            C0.N84();
            C0.N93();
        }

        public static void N78()
        {
            C0.N7();
            C0.N20();
            C0.N21();
            C0.N31();
            C0.N38();
            C0.N53();
            C0.N66();
            C0.N70();
            C0.N77();
            C0.N79();
            C0.N80();
            C0.N83();
            C0.N97();
        }

        public static void N79()
        {
            C0.N5();
            C0.N31();
            C0.N45();
            C0.N46();
            C0.N47();
            C0.N73();
            C0.N74();
            C0.N90();
            C0.N91();
        }

        public static void N80()
        {
            C0.N7();
            C0.N8();
            C0.N11();
            C0.N15();
            C0.N24();
            C0.N26();
            C0.N32();
            C0.N64();
            C0.N66();
            C0.N70();
            C0.N71();
            C0.N84();
            C0.N91();
            C0.N93();
        }

        public static void N81()
        {
            C0.N4();
            C0.N27();
            C0.N38();
            C0.N45();
            C0.N47();
            C0.N49();
            C0.N51();
            C0.N57();
            C0.N61();
            C0.N63();
            C0.N69();
            C0.N70();
            C0.N71();
            C0.N77();
            C0.N78();
            C0.N94();
            C0.N95();
        }

        public static void N82()
        {
            C0.N2();
            C0.N10();
            C0.N11();
            C0.N25();
            C0.N27();
            C0.N51();
            C0.N61();
            C0.N72();
            C0.N78();
            C0.N98();
        }

        public static void N83()
        {
            C0.N3();
            C0.N5();
            C0.N15();
            C0.N41();
            C0.N55();
            C0.N67();
            C0.N77();
            C0.N85();
            C0.N90();
            C0.N98();
        }

        public static void N84()
        {
            C0.N7();
            C0.N31();
            C0.N45();
            C0.N49();
            C0.N57();
            C0.N58();
            C0.N70();
            C0.N86();
            C0.N90();
            C0.N97();
        }

        public static void N85()
        {
            C0.N15();
            C0.N21();
            C0.N23();
            C0.N24();
            C0.N29();
            C0.N33();
            C0.N46();
            C0.N49();
            C0.N65();
            C0.N74();
            C0.N88();
        }

        public static void N86()
        {
            C0.N1();
            C0.N18();
            C0.N36();
            C0.N64();
            C0.N67();
            C0.N68();
            C0.N83();
        }

        public static void N87()
        {
            C0.N4();
            C0.N12();
            C0.N36();
            C0.N52();
            C0.N53();
            C0.N54();
            C0.N55();
            C0.N68();
            C0.N81();
            C0.N95();
        }

        public static void N88()
        {
            C0.N16();
            C0.N18();
            C0.N20();
            C0.N27();
            C0.N45();
            C0.N50();
            C0.N61();
            C0.N70();
            C0.N91();
            C0.N97();
        }

        public static void N89()
        {
            C0.N3();
            C0.N10();
            C0.N14();
            C0.N26();
            C0.N28();
            C0.N32();
            C0.N33();
            C0.N37();
            C0.N46();
            C0.N67();
            C0.N76();
            C0.N77();
            C0.N78();
            C0.N80();
            C0.N87();
        }

        public static void N90()
        {
            C0.N5();
            C0.N9();
            C0.N14();
            C0.N17();
            C0.N22();
            C0.N30();
            C0.N39();
            C0.N43();
            C0.N60();
            C0.N68();
            C0.N75();
            C0.N78();
            C0.N79();
            C0.N87();
        }

        public static void N91()
        {
            C0.N25();
            C0.N38();
            C0.N40();
            C0.N68();
            C0.N75();
            C0.N94();
        }

        public static void N92()
        {
            C0.N8();
            C0.N23();
            C0.N24();
            C0.N26();
            C0.N30();
            C0.N31();
            C0.N37();
            C0.N41();
            C0.N43();
            C0.N64();
            C0.N69();
            C0.N97();
        }

        public static void N93()
        {
            C0.N1();
            C0.N6();
            C0.N37();
            C0.N53();
            C0.N82();
        }

        public static void N94()
        {
            C0.N8();
            C0.N13();
            C0.N23();
            C0.N25();
            C0.N26();
            C0.N27();
            C0.N28();
            C0.N50();
            C0.N51();
            C0.N63();
            C0.N65();
            C0.N69();
            C0.N84();
        }

        public static void N95()
        {
            C0.N0();
            C0.N18();
            C0.N32();
            C0.N46();
            C0.N67();
            C0.N76();
            C0.N81();
            C0.N84();
            C0.N87();
        }

        public static void N96()
        {
            C0.N27();
            C0.N38();
            C0.N41();
            C0.N50();
            C0.N55();
            C0.N61();
            C0.N76();
            C0.N86();
        }

        public static void N97()
        {
            C0.N0();
            C0.N13();
            C0.N14();
            C0.N24();
            C0.N63();
            C0.N68();
            C0.N84();
        }

        public static void N98()
        {
            C0.N10();
            C0.N12();
            C0.N22();
            C0.N24();
            C0.N32();
            C0.N36();
            C0.N38();
            C0.N40();
            C0.N48();
            C0.N56();
            C0.N72();
            C0.N94();
        }

        public static void N99()
        {
        }

        public static void Main()
        {
            C0.N41();
        }
    }
}