using N1;
using N2;
using N3;
using N4;
using System;

namespace N0
{
public class C0
{
public static void M1()
{
C2.M60();
C1.M31();
C0.M2();
}
public static void M2()
{
C4.M90();
C1.M22();
C0.M3();
}
public static void M3()
{
C2.M52();
C0.M4();
}
public static void M4()
{
C2.M51();
C0.M5();
}
public static void M5()
{
C1.M29();
C4.M83();
C1.M28();
C0.M6();
}
public static void M6()
{
C2.M56();
C3.M75();
C0.M7();
}
public static void M7()
{
C2.M51();
C2.M52();
C0.M8();
}
public static void M8()
{
C2.M60();
C2.M59();
C0.M8();
C3.M61();
C0.M9();
}
public static void M9()
{
C4.M85();
C1.M29();
C0.M10();
}
public static void M10()
{
C3.M70();
C0.M11();
}
public static void M11()
{
C4.M95();
C3.M73();
C1.M36();
C3.M70();
C0.M12();
}
public static void M12()
{
C0.M16();
C0.M13();
}
public static void M13()
{
C0.M9();
C0.M14();
}
public static void M14()
{
C0.M15();
C0.M3();
C2.M46();
C0.M19();
}
public static void M15()
{
C1.M32();
C1.M26();
C1.M23();
C0.M16();
}
public static void M16()
{
C0.M20();
C1.M27();
C0.M17();
}
public static void M17()
{
C1.M31();
C0.M20();
C1.M28();
C3.M77();
C0.M18();
}
public static void M18()
{
C1.M24();
C0.M19();
}
public static void M19()
{
C2.M56();
C1.M35();
C4.M90();
C2.M41();
C0.M20();
}
public static void M20()
{
C2.M59();
C3.M67();
C2.M55();
C1.M21();
}
public static void Main(string[] args)
{
C0.M1();
}
}
}
