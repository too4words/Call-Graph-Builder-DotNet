using N2;
using N3;
using N4;
using System;

namespace N1
{
public class C1
{
public static void M21()
{
C1.M36();
C4.M81();
C4.M90();
C1.M22();
}
public static void M22()
{
C4.M82();
C4.M87();
C2.M57();
C1.M23();
}
public static void M23()
{
C2.M53();
C1.M23();
C1.M24();
}
public static void M24()
{
C4.M83();
C3.M77();
C1.M25();
}
public static void M25()
{
C1.M39();
C4.M85();
C1.M36();
C4.M90();
C1.M26();
}
public static void M26()
{
C3.M71();
C1.M27();
}
public static void M27()
{
C3.M68();
C4.M94();
C1.M28();
}
public static void M28()
{
C3.M76();
C4.M87();
C1.M31();
C3.M78();
C1.M29();
}
public static void M29()
{
C1.M22();
C3.M68();
C2.M53();
C1.M37();
C1.M30();
}
public static void M30()
{
C4.M92();
C1.M22();
C3.M64();
C1.M31();
}
public static void M31()
{
C3.M80();
C1.M32();
}
public static void M32()
{
C3.M63();
C1.M33();
}
public static void M33()
{
C1.M36();
C2.M55();
C1.M34();
}
public static void M34()
{
C2.M46();
C4.M81();
C1.M35();
}
public static void M35()
{
C2.M56();
C1.M36();
}
public static void M36()
{
C4.M92();
C3.M67();
C1.M37();
}
public static void M37()
{
C3.M66();
C4.M85();
C1.M38();
}
public static void M38()
{
C4.M84();
C1.M39();
}
public static void M39()
{
C3.M77();
C3.M78();
C2.M43();
C2.M51();
C1.M40();
}
public static void M40()
{
C1.M24();
C3.M67();
C2.M41();
}
}
}
