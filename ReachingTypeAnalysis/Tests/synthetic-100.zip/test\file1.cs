using N2;
using N3;
using N4;
using System;

namespace N1
{
public class C1
{
public static void M21()
{
C3.M65();
C2.M56();
C1.M22();
}
public static void M22()
{
C3.M67();
C2.M42();
C1.M23();
}
public static void M23()
{
C2.M50();
C4.M96();
C1.M32();
C1.M24();
}
public static void M24()
{
C2.M47();
C2.M43();
C1.M25();
}
public static void M25()
{
C3.M70();
C1.M26();
}
public static void M26()
{
C4.M92();
C2.M54();
C1.M23();
C3.M71();
C1.M27();
}
public static void M27()
{
C1.M27();
C4.M93();
C4.M98();
C1.M28();
}
public static void M28()
{
C2.M53();
C3.M61();
C3.M67();
C1.M39();
C1.M29();
}
public static void M29()
{
C4.M95();
C3.M66();
C1.M25();
C1.M30();
}
public static void M30()
{
C4.M81();
C3.M72();
C4.M94();
C4.M82();
C1.M31();
}
public static void M31()
{
C3.M68();
C3.M78();
C4.M84();
C1.M32();
}
public static void M32()
{
C3.M70();
C3.M67();
C1.M33();
}
public static void M33()
{
C2.M57();
C2.M58();
C3.M76();
C1.M23();
C1.M34();
}
public static void M34()
{
C1.M26();
C3.M65();
C1.M35();
}
public static void M35()
{
C1.M21();
C1.M36();
}
public static void M36()
{
C3.M71();
C2.M57();
C1.M37();
}
public static void M37()
{
C1.M34();
C3.M80();
C1.M38();
}
public static void M38()
{
C1.M32();
C2.M48();
C1.M35();
C4.M85();
C1.M39();
}
public static void M39()
{
C3.M61();
C2.M44();
C1.M40();
}
public static void M40()
{
C4.M94();
C1.M30();
C3.M79();
C2.M53();
C2.M41();
}
}
}
