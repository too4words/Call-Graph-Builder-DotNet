using N3;
using N4;
using System;

namespace N2
{
public class C2
{
public static void M41()
{
C4.M93();
C2.M42();
}
public static void M42()
{
C4.M87();
C3.M77();
C2.M43();
}
public static void M43()
{
C3.M64();
C3.M70();
C2.M49();
C2.M44();
}
public static void M44()
{
C3.M73();
C2.M45();
}
public static void M45()
{
C2.M56();
C3.M69();
C4.M87();
C2.M46();
}
public static void M46()
{
C4.M88();
C3.M73();
C2.M58();
C3.M70();
C2.M47();
}
public static void M47()
{
C2.M58();
C2.M60();
C2.M46();
C2.M48();
}
public static void M48()
{
C4.M84();
C3.M65();
C2.M42();
C3.M64();
C2.M49();
}
public static void M49()
{
C2.M49();
C4.M96();
C2.M50();
C4.M90();
}
public static void M50()
{
C3.M64();
C3.M67();
C2.M51();
}
public static void M51()
{
C4.M88();
C4.M87();
C2.M52();
}
public static void M52()
{
C2.M46();
C2.M55();
C3.M71();
C2.M53();
}
public static void M53()
{
C3.M65();
C3.M73();
C2.M54();
}
public static void M54()
{
C4.M94();
C4.M85();
C2.M55();
}
public static void M55()
{
C4.M89();
C2.M48();
C2.M56();
}
public static void M56()
{
C4.M97();
C4.M82();
C3.M74();
C2.M57();
}
public static void M57()
{
C4.M89();
C2.M58();
}
public static void M58()
{
C2.M46();
C3.M62();
C2.M59();
C4.M93();
}
public static void M59()
{
C3.M68();
C3.M64();
C2.M49();
C2.M60();
}
public static void M60()
{
C3.M70();
C3.M69();
C3.M61();
}
}
}
