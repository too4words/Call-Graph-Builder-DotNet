using N1;
using N2;
using N3;
using N4;
using N5;
using N6;
using N7;
using N8;
using N9;
using System;

namespace N0
{
public class C0
{
public static void M1()
{
C1.M137();
C7.M727();
C3.M400();
C6.M631();
C3.M309();
C1.M166();
C2.M274();
C4.M490();
C1.M162();
C0.M2();
}
public static void M2()
{
C1.M170();
C2.M271();
C2.M266();
C0.M13();
C0.M3();
}
public static void M3()
{
C6.M636();
C2.M275();
C0.M4();
}
public static void M4()
{
C7.M753();
C1.M151();
C0.M5();
}
public static void M5()
{
C8.M880();
C4.M405();
C2.M230();
C2.M283();
C1.M171();
C3.M305();
C7.M745();
C0.M6();
}
public static void M6()
{
C5.M561();
C6.M688();
C3.M308();
C4.M476();
C8.M878();
C3.M314();
C1.M191();
C8.M826();
C9.M965();
C0.M7();
}
public static void M7()
{
C5.M532();
C0.M8();
}
public static void M8()
{
C9.M990();
C4.M477();
C1.M185();
C8.M834();
C2.M246();
C5.M596();
C0.M9();
}
public static void M9()
{
C2.M206();
C9.M936();
C7.M798();
C3.M388();
C6.M686();
C0.M10();
}
public static void M10()
{
C2.M294();
C2.M256();
C3.M323();
C1.M171();
C3.M349();
C0.M11();
}
public static void M11()
{
C8.M859();
C5.M527();
C0.M12();
}
public static void M12()
{
C5.M599();
C7.M753();
C8.M860();
C7.M793();
C3.M387();
C6.M698();
C0.M13();
}
public static void M13()
{
C8.M809();
C3.M309();
C1.M115();
C2.M221();
C5.M503();
C7.M701();
C4.M403();
C2.M220();
C3.M394();
C0.M14();
}
public static void M14()
{
C5.M574();
C0.M15();
}
public static void M15()
{
C5.M540();
C9.M966();
C7.M762();
C3.M301();
C6.M620();
C0.M14();
C5.M584();
C0.M58();
C0.M16();
}
public static void M16()
{
C6.M655();
C6.M617();
C9.M966();
C6.M672();
C1.M120();
C4.M406();
C8.M877();
C4.M431();
C0.M17();
}
public static void M17()
{
C4.M451();
C2.M209();
C7.M753();
C2.M240();
C1.M127();
C4.M489();
C2.M273();
C4.M466();
C9.M958();
C0.M18();
}
public static void M18()
{
C8.M852();
C1.M104();
C7.M775();
C3.M311();
C5.M564();
C0.M8();
C0.M19();
}
public static void M19()
{
C6.M618();
C8.M836();
C4.M453();
C2.M241();
C7.M780();
C8.M801();
C6.M640();
C0.M98();
C1.M154();
C0.M20();
}
public static void M20()
{
C1.M148();
C5.M548();
C3.M384();
C2.M296();
C5.M525();
C7.M787();
C4.M420();
C0.M21();
}
public static void M21()
{
C3.M365();
C0.M99();
C3.M301();
C8.M839();
C2.M274();
C0.M28();
C0.M22();
}
public static void M22()
{
C0.M54();
C9.M991();
C0.M23();
}
public static void M23()
{
C7.M763();
C8.M879();
C0.M24();
}
public static void M24()
{
C4.M402();
C6.M664();
C1.M133();
C0.M25();
}
public static void M25()
{
C0.M41();
C9.M977();
C7.M732();
C6.M670();
C4.M407();
C1.M113();
C1.M142();
C9.M972();
C0.M26();
}
public static void M26()
{
C1.M126();
C9.M916();
C5.M575();
C2.M296();
C3.M328();
C3.M315();
C3.M355();
C7.M724();
C0.M27();
}
public static void M27()
{
C9.M907();
C6.M685();
C0.M28();
}
public static void M28()
{
C5.M562();
C4.M425();
C0.M86();
C7.M726();
C8.M808();
C4.M436();
C3.M334();
C2.M274();
C0.M29();
}
public static void M29()
{
C7.M744();
C8.M882();
C2.M251();
C5.M508();
C0.M30();
}
public static void M30()
{
C8.M809();
C6.M687();
C9.M914();
C9.M957();
C9.M985();
C0.M31();
}
public static void M31()
{
C8.M866();
C4.M476();
C0.M32();
}
public static void M32()
{
C2.M237();
C4.M478();
C6.M696();
C8.M876();
C4.M449();
C5.M524();
C5.M581();
C2.M204();
C7.M756();
C0.M33();
}
public static void M33()
{
C0.M10();
C4.M478();
C5.M552();
C6.M646();
C9.M942();
C0.M34();
}
public static void M34()
{
C6.M676();
C8.M807();
C6.M698();
C4.M412();
C3.M380();
C0.M35();
}
public static void M35()
{
C7.M787();
C8.M843();
C5.M504();
C0.M36();
}
public static void M36()
{
C8.M808();
C2.M241();
C9.M921();
C5.M526();
C9.M910();
C0.M87();
C5.M523();
C0.M37();
}
public static void M37()
{
C2.M248();
C1.M113();
C5.M558();
C8.M883();
C7.M749();
C8.M802();
C5.M541();
C1.M126();
C0.M38();
}
public static void M38()
{
C4.M499();
C0.M6();
C2.M257();
C0.M42();
C9.M970();
C3.M361();
C3.M309();
C3.M351();
C0.M39();
}
public static void M39()
{
C0.M64();
C5.M521();
C0.M40();
}
public static void M40()
{
C1.M154();
C9.M908();
C0.M41();
}
public static void M41()
{
C9.M943();
C0.M42();
}
public static void M42()
{
C7.M772();
C9.M962();
C8.M834();
C9.M919();
C0.M98();
C3.M391();
C0.M30();
C7.M797();
C0.M43();
}
public static void M43()
{
C4.M484();
C1.M118();
C9.M922();
C9.M947();
C6.M609();
C8.M838();
C9.M907();
C0.M44();
}
public static void M44()
{
C2.M289();
C8.M837();
C2.M248();
C6.M626();
C8.M836();
C0.M45();
}
public static void M45()
{
C6.M612();
C1.M176();
C7.M742();
C0.M24();
C0.M2();
C6.M645();
C0.M94();
C2.M204();
C0.M46();
}
public static void M46()
{
C9.M939();
C8.M892();
C0.M31();
C5.M577();
C2.M291();
C0.M47();
}
public static void M47()
{
C4.M401();
C6.M614();
C2.M228();
C2.M243();
C2.M276();
C8.M875();
C1.M192();
C4.M427();
C0.M48();
}
public static void M48()
{
C4.M454();
C6.M682();
C0.M49();
}
public static void M49()
{
C6.M632();
C6.M619();
C1.M195();
C0.M50();
}
public static void M50()
{
C2.M230();
C9.M934();
C0.M84();
C2.M222();
C7.M744();
C3.M355();
C3.M368();
C0.M51();
}
public static void M51()
{
C1.M153();
C0.M52();
}
public static void M52()
{
C2.M281();
C5.M591();
C9.M982();
C0.M55();
C5.M578();
C2.M261();
C0.M53();
}
public static void M53()
{
C6.M638();
C8.M886();
C2.M223();
C0.M20();
C3.M384();
C5.M560();
C0.M54();
}
public static void M54()
{
C4.M421();
C0.M55();
}
public static void M55()
{
C5.M523();
C5.M568();
C3.M319();
C3.M351();
C4.M460();
C5.M583();
C3.M331();
C0.M56();
}
public static void M56()
{
C6.M663();
C0.M95();
C4.M494();
C0.M57();
}
public static void M57()
{
C1.M138();
C0.M58();
}
public static void M58()
{
C2.M246();
C0.M59();
}
public static void M59()
{
C0.M91();
C6.M674();
C0.M60();
}
public static void M60()
{
C5.M599();
C4.M443();
C1.M164();
C8.M874();
C4.M422();
C6.M676();
C0.M61();
}
public static void M61()
{
C7.M731();
C9.M970();
C6.M676();
C8.M845();
C3.M375();
C0.M81();
C7.M800();
C9.M995();
C8.M830();
C0.M62();
}
public static void M62()
{
C7.M707();
C7.M800();
C1.M141();
C6.M696();
C2.M261();
C7.M739();
C3.M391();
C4.M484();
C0.M63();
}
public static void M63()
{
C5.M548();
C5.M501();
C8.M841();
C9.M975();
C8.M818();
C2.M293();
C8.M885();
C0.M64();
}
public static void M64()
{
C8.M820();
C3.M305();
C3.M359();
C6.M693();
C0.M65();
}
public static void M65()
{
C6.M673();
C4.M467();
C8.M850();
C3.M359();
C5.M565();
C8.M817();
C7.M718();
C4.M413();
C2.M267();
C0.M66();
}
public static void M66()
{
C2.M214();
C4.M447();
C0.M67();
}
public static void M67()
{
C2.M289();
C5.M533();
C8.M897();
C3.M338();
C7.M702();
C0.M68();
}
public static void M68()
{
C3.M390();
C6.M655();
C1.M129();
C4.M492();
C8.M889();
C9.M993();
C8.M857();
C0.M69();
}
public static void M69()
{
C4.M488();
C6.M672();
C9.M978();
C6.M691();
C4.M472();
C0.M70();
}
public static void M70()
{
C8.M811();
C0.M71();
}
public static void M71()
{
C6.M673();
C8.M845();
C0.M72();
}
public static void M72()
{
C1.M175();
C5.M572();
C7.M764();
C3.M353();
C2.M281();
C3.M360();
C6.M627();
C5.M529();
C3.M327();
C0.M73();
}
public static void M73()
{
C3.M353();
C0.M74();
}
public static void M74()
{
C4.M483();
C6.M601();
C5.M585();
C3.M303();
C2.M241();
C0.M75();
}
public static void M75()
{
C9.M973();
C9.M959();
C3.M364();
C7.M707();
C2.M266();
C0.M76();
}
public static void M76()
{
C7.M739();
C2.M288();
C4.M449();
C0.M77();
}
public static void M77()
{
C3.M341();
C6.M680();
C1.M162();
C8.M858();
C0.M53();
C4.M435();
C5.M528();
C0.M78();
}
public static void M78()
{
C6.M625();
C3.M303();
C0.M79();
}
public static void M79()
{
C1.M132();
C2.M263();
C4.M465();
C5.M531();
C5.M548();
C1.M136();
C1.M164();
C4.M496();
C0.M80();
}
public static void M80()
{
C8.M885();
C0.M81();
}
public static void M81()
{
C5.M570();
C5.M581();
C6.M698();
C8.M884();
C5.M538();
C4.M467();
C3.M307();
C5.M534();
C0.M82();
}
public static void M82()
{
C9.M992();
C9.M910();
C8.M884();
C1.M189();
C6.M645();
C8.M841();
C0.M83();
}
public static void M83()
{
C4.M457();
C0.M48();
C0.M73();
C3.M385();
C6.M676();
C0.M84();
}
public static void M84()
{
C6.M697();
C8.M842();
C8.M898();
C1.M176();
C7.M717();
C0.M95();
C5.M576();
C7.M790();
C3.M358();
C0.M85();
}
public static void M85()
{
C5.M538();
C1.M110();
C5.M579();
C1.M161();
C1.M167();
C8.M896();
C0.M62();
C8.M893();
C0.M86();
}
public static void M86()
{
C6.M689();
C0.M87();
}
public static void M87()
{
C2.M220();
C3.M378();
C2.M277();
C8.M884();
C7.M705();
C6.M642();
C7.M706();
C4.M448();
C0.M88();
}
public static void M88()
{
C5.M501();
C0.M89();
}
public static void M89()
{
C6.M632();
C8.M882();
C0.M90();
}
public static void M90()
{
C1.M188();
C6.M639();
C2.M291();
C5.M589();
C4.M439();
C0.M36();
C2.M202();
C5.M552();
C0.M91();
}
public static void M91()
{
C6.M649();
C0.M92();
}
public static void M92()
{
C2.M262();
C3.M332();
C2.M290();
C1.M151();
C0.M11();
C0.M93();
}
public static void M93()
{
C5.M585();
C2.M248();
C8.M843();
C6.M622();
C3.M319();
C0.M94();
}
public static void M94()
{
C2.M291();
C0.M12();
C4.M451();
C8.M869();
C3.M343();
C3.M341();
C0.M95();
}
public static void M95()
{
C4.M413();
C4.M476();
C6.M696();
C3.M304();
C0.M96();
}
public static void M96()
{
C2.M258();
C7.M770();
C3.M304();
C6.M651();
C6.M654();
C6.M667();
C3.M348();
C6.M626();
C4.M444();
C0.M97();
}
public static void M97()
{
C4.M416();
C2.M298();
C0.M8();
C0.M98();
}
public static void M98()
{
C5.M539();
C0.M99();
}
public static void M99()
{
C0.M40();
C2.M234();
C8.M867();
C0.M18();
C0.M100();
}
public static void M100()
{
C5.M577();
C9.M986();
C1.M166();
C8.M858();
C2.M212();
C6.M674();
C2.M237();
C0.M60();
C5.M565();
C1.M101();
}
public static void Main(string[] args)
{
C0.M1();
}
}
}
