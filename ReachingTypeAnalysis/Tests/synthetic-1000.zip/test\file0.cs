using N1;
using N2;
using N3;
using N4;
using N5;
using N6;
using N7;
using N8;
using N9;
using System;

namespace N0
{
public class C0
{
public static void M1()
{
C5.M568();
C7.M758();
C0.M59();
C9.M994();
C6.M621();
C2.M218();
C0.M2();
}
public static void M2()
{
C2.M207();
C9.M939();
C9.M983();
C5.M541();
C6.M620();
C9.M916();
C0.M48();
C0.M3();
}
public static void M3()
{
C2.M204();
C0.M64();
C3.M322();
C6.M681();
C0.M4();
}
public static void M4()
{
C4.M427();
C0.M58();
C0.M5();
}
public static void M5()
{
C6.M633();
C8.M850();
C1.M154();
C2.M300();
C1.M101();
C6.M625();
C5.M596();
C2.M220();
C9.M938();
C0.M6();
}
public static void M6()
{
C7.M774();
C8.M899();
C2.M289();
C5.M526();
C9.M986();
C0.M51();
C9.M980();
C0.M7();
}
public static void M7()
{
C1.M193();
C7.M799();
C6.M610();
C6.M696();
C9.M922();
C8.M802();
C7.M752();
C9.M932();
C0.M8();
}
public static void M8()
{
C4.M467();
C0.M69();
C6.M696();
C6.M620();
C0.M9();
}
public static void M9()
{
C5.M511();
C8.M817();
C0.M10();
}
public static void M10()
{
C1.M144();
C4.M467();
C9.M917();
C6.M668();
C0.M11();
}
public static void M11()
{
C3.M343();
C7.M763();
C6.M601();
C8.M844();
C1.M142();
C1.M147();
C0.M12();
}
public static void M12()
{
C6.M676();
C0.M76();
C0.M13();
}
public static void M13()
{
C6.M699();
C3.M323();
C2.M234();
C0.M14();
}
public static void M14()
{
C3.M330();
C9.M935();
C9.M927();
C0.M15();
}
public static void M15()
{
C5.M546();
C1.M168();
C2.M205();
C1.M129();
C0.M16();
}
public static void M16()
{
C2.M243();
C1.M156();
C0.M17();
}
public static void M17()
{
C3.M389();
C4.M470();
C1.M103();
C8.M843();
C5.M583();
C0.M63();
C0.M18();
}
public static void M18()
{
C6.M611();
C4.M457();
C0.M19();
}
public static void M19()
{
C0.M96();
C0.M79();
C6.M660();
C6.M605();
C8.M814();
C7.M743();
C3.M392();
C7.M797();
C0.M20();
}
public static void M20()
{
C2.M297();
C9.M901();
C2.M254();
C4.M487();
C2.M216();
C1.M117();
C3.M372();
C5.M501();
C3.M376();
C0.M21();
}
public static void M21()
{
C6.M611();
C3.M359();
C0.M22();
}
public static void M22()
{
C5.M503();
C7.M757();
C6.M647();
C5.M574();
C2.M232();
C6.M687();
C6.M637();
C0.M23();
}
public static void M23()
{
C6.M622();
C7.M799();
C0.M24();
}
public static void M24()
{
C8.M840();
C8.M849();
C6.M688();
C9.M939();
C3.M353();
C0.M25();
}
public static void M25()
{
C7.M736();
C3.M354();
C2.M246();
C8.M857();
C1.M135();
C0.M26();
}
public static void M26()
{
C6.M614();
C6.M627();
C4.M466();
C6.M690();
C6.M624();
C2.M235();
C2.M243();
C7.M735();
C3.M388();
C0.M27();
}
public static void M27()
{
C8.M846();
C1.M167();
C0.M28();
}
public static void M28()
{
C1.M160();
C1.M111();
C0.M29();
}
public static void M29()
{
C0.M100();
C2.M279();
C4.M454();
C0.M5();
C0.M30();
}
public static void M30()
{
C3.M366();
C4.M427();
C4.M431();
C1.M149();
C9.M913();
C4.M476();
C0.M31();
}
public static void M31()
{
C1.M113();
C8.M830();
C7.M765();
C0.M32();
}
public static void M32()
{
C6.M664();
C9.M959();
C6.M603();
C2.M221();
C9.M946();
C5.M572();
C0.M33();
}
public static void M33()
{
C5.M557();
C2.M249();
C1.M105();
C4.M461();
C0.M34();
}
public static void M34()
{
C0.M93();
C1.M186();
C2.M293();
C5.M577();
C2.M243();
C0.M35();
}
public static void M35()
{
C7.M757();
C4.M457();
C6.M679();
C9.M977();
C9.M967();
C2.M262();
C0.M39();
C2.M259();
C0.M36();
}
public static void M36()
{
C3.M320();
C7.M765();
C9.M975();
C6.M623();
C5.M557();
C0.M37();
}
public static void M37()
{
C2.M224();
C5.M501();
C2.M209();
C5.M555();
C0.M38();
}
public static void M38()
{
C4.M411();
C5.M527();
C8.M890();
C8.M895();
C7.M754();
C5.M541();
C9.M904();
C3.M338();
C9.M961();
C0.M39();
}
public static void M39()
{
C8.M898();
C0.M15();
C2.M226();
C0.M74();
C3.M308();
C9.M942();
C0.M40();
}
public static void M40()
{
C9.M991();
C3.M342();
C1.M183();
C6.M687();
C0.M97();
C0.M68();
C7.M791();
C0.M41();
}
public static void M41()
{
C4.M481();
C9.M903();
C1.M140();
C0.M42();
}
public static void M42()
{
C6.M683();
C0.M85();
C0.M22();
C3.M354();
C4.M475();
C2.M231();
C5.M566();
C7.M782();
C0.M43();
}
public static void M43()
{
C4.M426();
C3.M357();
C1.M142();
C0.M44();
}
public static void M44()
{
C5.M513();
C6.M698();
C8.M865();
C9.M960();
C3.M397();
C4.M483();
C0.M83();
C2.M280();
C8.M814();
C0.M45();
}
public static void M45()
{
C2.M214();
C7.M706();
C0.M46();
}
public static void M46()
{
C4.M430();
C8.M822();
C1.M105();
C4.M482();
C0.M60();
C0.M1();
C7.M756();
C0.M47();
}
public static void M47()
{
C2.M278();
C5.M537();
C8.M876();
C6.M660();
C7.M750();
C0.M48();
}
public static void M48()
{
C7.M741();
C1.M161();
C4.M463();
C5.M565();
C9.M983();
C0.M41();
C7.M766();
C5.M583();
C0.M49();
}
public static void M49()
{
C9.M924();
C3.M311();
C0.M84();
C4.M420();
C0.M50();
}
public static void M50()
{
C5.M589();
C0.M51();
}
public static void M51()
{
C8.M867();
C8.M807();
C6.M647();
C7.M751();
C7.M799();
C7.M743();
C6.M677();
C7.M741();
C0.M52();
}
public static void M52()
{
C3.M356();
C3.M385();
C4.M451();
C2.M235();
C0.M53();
}
public static void M53()
{
C9.M987();
C3.M301();
C0.M54();
}
public static void M54()
{
C6.M640();
C3.M341();
C1.M120();
C3.M351();
C6.M650();
C2.M229();
C0.M55();
}
public static void M55()
{
C9.M955();
C8.M845();
C4.M453();
C1.M180();
C1.M171();
C9.M975();
C0.M56();
}
public static void M56()
{
C6.M700();
C8.M878();
C4.M409();
C6.M668();
C0.M70();
C0.M14();
C0.M57();
}
public static void M57()
{
C0.M43();
C9.M996();
C4.M482();
C7.M721();
C1.M200();
C6.M628();
C6.M654();
C3.M315();
C3.M348();
C0.M58();
}
public static void M58()
{
C9.M935();
C0.M11();
C0.M59();
}
public static void M59()
{
C7.M779();
C7.M714();
C4.M470();
C5.M517();
C0.M60();
}
public static void M60()
{
C5.M579();
C9.M980();
C0.M61();
}
public static void M61()
{
C9.M953();
C2.M290();
C4.M498();
C5.M570();
C3.M390();
C7.M775();
C6.M684();
C5.M572();
C0.M62();
}
public static void M62()
{
C4.M492();
C9.M918();
C2.M287();
C6.M647();
C5.M598();
C3.M344();
C6.M636();
C6.M629();
C0.M63();
}
public static void M63()
{
C5.M600();
C0.M11();
C6.M640();
C4.M497();
C2.M246();
C0.M64();
}
public static void M64()
{
C1.M160();
C5.M538();
C7.M800();
C0.M65();
}
public static void M65()
{
C4.M408();
C8.M890();
C4.M450();
C4.M489();
C0.M33();
C2.M203();
C0.M88();
C7.M706();
C9.M982();
C0.M66();
}
public static void M66()
{
C8.M808();
C8.M852();
C0.M67();
}
public static void M67()
{
C7.M742();
C5.M522();
C7.M714();
C0.M17();
C7.M722();
C7.M788();
C1.M181();
C3.M370();
C8.M832();
C0.M68();
}
public static void M68()
{
C7.M766();
C9.M978();
C9.M969();
C1.M155();
C4.M456();
C0.M45();
C2.M255();
C4.M410();
C0.M69();
}
public static void M69()
{
C9.M973();
C6.M698();
C1.M164();
C9.M934();
C0.M42();
C4.M429();
C2.M255();
C4.M445();
C0.M70();
}
public static void M70()
{
C6.M636();
C6.M653();
C4.M479();
C6.M641();
C7.M746();
C0.M71();
}
public static void M71()
{
C8.M896();
C0.M72();
}
public static void M72()
{
C5.M530();
C2.M226();
C4.M437();
C7.M749();
C6.M619();
C6.M615();
C5.M575();
C0.M4();
C6.M683();
C0.M73();
}
public static void M73()
{
C0.M62();
C0.M48();
C6.M631();
C6.M662();
C7.M727();
C0.M74();
}
public static void M74()
{
C9.M956();
C8.M877();
C2.M272();
C5.M578();
C5.M586();
C6.M673();
C5.M587();
C0.M75();
}
public static void M75()
{
C3.M344();
C6.M670();
C7.M733();
C1.M180();
C4.M408();
C0.M76();
}
public static void M76()
{
C2.M232();
C9.M929();
C0.M77();
}
public static void M77()
{
C4.M480();
C5.M513();
C0.M29();
C0.M78();
}
public static void M78()
{
C1.M102();
C3.M355();
C0.M83();
C5.M588();
C9.M930();
C3.M358();
C9.M918();
C1.M194();
C3.M397();
C0.M79();
}
public static void M79()
{
C9.M972();
C9.M924();
C7.M739();
C6.M683();
C8.M868();
C7.M767();
C3.M318();
C3.M388();
C0.M80();
}
public static void M80()
{
C6.M638();
C9.M968();
C4.M405();
C9.M947();
C8.M881();
C3.M396();
C5.M595();
C5.M558();
C0.M81();
}
public static void M81()
{
C1.M132();
C7.M789();
C1.M151();
C0.M82();
}
public static void M82()
{
C6.M698();
C7.M765();
C0.M83();
}
public static void M83()
{
C5.M522();
C1.M190();
C9.M989();
C6.M655();
C3.M316();
C6.M667();
C2.M274();
C9.M946();
C0.M84();
}
public static void M84()
{
C7.M759();
C2.M254();
C6.M668();
C4.M441();
C3.M362();
C1.M163();
C9.M938();
C0.M93();
C0.M85();
}
public static void M85()
{
C3.M390();
C0.M5();
C6.M695();
C4.M407();
C2.M201();
C1.M193();
C0.M86();
}
public static void M86()
{
C7.M798();
C6.M640();
C0.M62();
C6.M606();
C0.M87();
}
public static void M87()
{
C8.M823();
C2.M226();
C9.M972();
C8.M827();
C3.M347();
C5.M577();
C3.M328();
C0.M88();
}
public static void M88()
{
C5.M541();
C9.M970();
C6.M694();
C4.M458();
C1.M156();
C1.M122();
C1.M142();
C0.M89();
}
public static void M89()
{
C1.M118();
C9.M915();
C9.M967();
C8.M850();
C0.M59();
C4.M493();
C3.M309();
C7.M761();
C1.M160();
C0.M90();
}
public static void M90()
{
C9.M987();
C7.M797();
C0.M91();
}
public static void M91()
{
C5.M516();
C0.M28();
C2.M212();
C0.M92();
}
public static void M92()
{
C0.M66();
C9.M934();
C0.M29();
C6.M694();
C0.M93();
}
public static void M93()
{
C0.M16();
C5.M584();
C6.M610();
C3.M359();
C1.M116();
C4.M419();
C0.M94();
}
public static void M94()
{
C2.M238();
C2.M251();
C0.M80();
C0.M95();
}
public static void M95()
{
C4.M409();
C0.M96();
}
public static void M96()
{
C7.M723();
C0.M93();
C7.M755();
C6.M668();
C3.M331();
C9.M915();
C2.M212();
C0.M97();
}
public static void M97()
{
C2.M231();
C5.M589();
C5.M529();
C4.M414();
C0.M25();
C9.M942();
C4.M482();
C0.M98();
}
public static void M98()
{
C0.M90();
C1.M187();
C0.M99();
}
public static void M99()
{
C2.M232();
C5.M504();
C0.M100();
}
public static void M100()
{
C3.M384();
C2.M240();
C6.M699();
C3.M377();
C8.M889();
C4.M452();
C9.M921();
C8.M863();
C9.M908();
C1.M101();
}
public static void Main(string[] args)
{
C0.M1();
}
}
}
