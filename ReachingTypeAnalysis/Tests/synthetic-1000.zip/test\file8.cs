using N9;
using System;

namespace N8
{
public class C8
{
public static void M801()
{
C8.M848();
C8.M835();
C8.M846();
C8.M836();
C9.M915();
C8.M896();
C9.M958();
C8.M824();
C8.M802();
}
public static void M802()
{
C8.M879();
C8.M880();
C9.M965();
C9.M962();
C9.M988();
C8.M803();
}
public static void M803()
{
C8.M869();
C9.M950();
C9.M970();
C9.M956();
C8.M804();
}
public static void M804()
{
C9.M933();
C9.M988();
C8.M805();
}
public static void M805()
{
C9.M935();
C9.M930();
C8.M880();
C8.M835();
C9.M981();
C8.M889();
C9.M925();
C9.M921();
C8.M806();
}
public static void M806()
{
C8.M860();
C8.M832();
C8.M813();
C9.M989();
C9.M981();
C9.M956();
C8.M816();
C9.M930();
C8.M807();
}
public static void M807()
{
C8.M867();
C8.M838();
C9.M974();
C9.M904();
C8.M808();
}
public static void M808()
{
C9.M964();
C9.M913();
C8.M858();
C9.M932();
C8.M853();
C8.M809();
}
public static void M809()
{
C8.M871();
C9.M941();
C8.M810();
}
public static void M810()
{
C8.M846();
C8.M872();
C8.M899();
C9.M984();
C8.M817();
C9.M924();
C8.M811();
}
public static void M811()
{
C8.M819();
C9.M952();
C8.M812();
}
public static void M812()
{
C9.M923();
C9.M905();
C9.M931();
C9.M976();
C8.M876();
C8.M887();
C9.M993();
C9.M954();
C8.M813();
}
public static void M813()
{
C9.M951();
C8.M867();
C8.M814();
}
public static void M814()
{
C9.M997();
C8.M831();
C8.M833();
C9.M914();
C9.M921();
C9.M923();
C9.M956();
C8.M815();
}
public static void M815()
{
C8.M891();
C8.M886();
C9.M917();
C9.M918();
C8.M816();
}
public static void M816()
{
C9.M918();
C8.M882();
C9.M971();
C9.M998();
C8.M807();
C8.M841();
C8.M849();
C8.M885();
C8.M817();
}
public static void M817()
{
C9.M979();
C8.M818();
}
public static void M818()
{
C8.M834();
C9.M936();
C9.M980();
C8.M845();
C8.M859();
C8.M875();
C9.M989();
C8.M846();
C8.M895();
C8.M819();
}
public static void M819()
{
C8.M868();
C9.M951();
C9.M901();
C8.M804();
C8.M820();
}
public static void M820()
{
C8.M861();
C8.M880();
C8.M867();
C8.M838();
C9.M986();
C8.M813();
C8.M821();
}
public static void M821()
{
C9.M957();
C8.M822();
}
public static void M822()
{
C8.M822();
C8.M823();
}
public static void M823()
{
C8.M820();
C9.M910();
C8.M819();
C8.M866();
C9.M980();
C8.M851();
C8.M842();
C8.M881();
C8.M824();
}
public static void M824()
{
C9.M941();
C9.M911();
C8.M815();
C8.M816();
C8.M842();
C9.M927();
C8.M872();
C8.M845();
C8.M814();
C8.M825();
}
public static void M825()
{
C8.M897();
C8.M826();
}
public static void M826()
{
C9.M922();
C8.M827();
}
public static void M827()
{
C8.M805();
C9.M948();
C9.M942();
C8.M821();
C9.M926();
C8.M824();
C8.M841();
C8.M837();
C9.M918();
C8.M828();
}
public static void M828()
{
C8.M879();
C8.M828();
C8.M829();
}
public static void M829()
{
C8.M892();
C8.M818();
C8.M830();
}
public static void M830()
{
C8.M820();
C8.M819();
C9.M974();
C9.M949();
C8.M865();
C8.M831();
}
public static void M831()
{
C9.M994();
C8.M860();
C9.M939();
C8.M832();
}
public static void M832()
{
C9.M912();
C9.M990();
C8.M802();
C8.M859();
C8.M816();
C9.M986();
C8.M832();
C8.M833();
}
public static void M833()
{
C8.M832();
C9.M907();
C8.M838();
C8.M834();
}
public static void M834()
{
C8.M858();
C9.M918();
C8.M871();
C8.M835();
}
public static void M835()
{
C8.M896();
C8.M817();
C8.M848();
C8.M845();
C8.M843();
C9.M952();
C9.M995();
C9.M909();
C8.M877();
C8.M836();
}
public static void M836()
{
C9.M947();
C8.M837();
C9.M939();
C8.M897();
C9.M946();
C9.M943();
C8.M880();
C9.M987();
C9.M910();
}
public static void M837()
{
C8.M835();
C8.M860();
C8.M810();
C8.M838();
}
public static void M838()
{
C9.M994();
C9.M967();
C8.M860();
C9.M910();
C8.M873();
C8.M839();
}
public static void M839()
{
C9.M959();
C8.M857();
C8.M879();
C8.M887();
C9.M954();
C9.M978();
C8.M813();
C8.M895();
C8.M840();
}
public static void M840()
{
C9.M959();
C9.M994();
C8.M891();
C9.M981();
C8.M831();
C8.M841();
}
public static void M841()
{
C9.M993();
C9.M921();
C8.M842();
}
public static void M842()
{
C9.M959();
C8.M893();
C9.M980();
C8.M870();
C8.M809();
C8.M822();
C9.M942();
C8.M843();
}
public static void M843()
{
C8.M807();
C9.M955();
C8.M844();
}
public static void M844()
{
C8.M874();
C8.M892();
C8.M885();
C8.M845();
}
public static void M845()
{
C9.M918();
C8.M825();
C8.M846();
}
public static void M846()
{
C9.M957();
C8.M852();
C9.M942();
C9.M967();
C9.M930();
C8.M847();
}
public static void M847()
{
C8.M892();
C9.M949();
C8.M854();
C9.M942();
C8.M878();
C9.M978();
C8.M852();
C8.M802();
C8.M847();
C8.M848();
}
public static void M848()
{
C9.M950();
C9.M978();
C9.M977();
C8.M890();
C8.M848();
C8.M858();
C8.M849();
}
public static void M849()
{
C9.M917();
C9.M972();
C8.M857();
C8.M846();
C8.M821();
C8.M868();
C9.M909();
C8.M850();
}
public static void M850()
{
C8.M864();
C8.M806();
C9.M948();
C8.M851();
}
public static void M851()
{
C8.M869();
C9.M991();
C8.M852();
}
public static void M852()
{
C9.M961();
C9.M994();
C9.M976();
C8.M858();
C9.M966();
C8.M801();
C9.M958();
C8.M828();
C9.M903();
C8.M853();
}
public static void M853()
{
C8.M828();
C9.M966();
C9.M934();
C8.M854();
}
public static void M854()
{
C9.M939();
C9.M934();
C8.M843();
C8.M855();
}
public static void M855()
{
C9.M908();
C8.M825();
C9.M993();
C8.M874();
C9.M939();
C8.M856();
}
public static void M856()
{
C8.M881();
C9.M944();
C8.M888();
C8.M815();
C8.M857();
}
public static void M857()
{
C9.M903();
C9.M963();
C9.M976();
C9.M932();
C9.M958();
C8.M817();
C9.M981();
C9.M913();
C8.M858();
}
public static void M858()
{
C8.M890();
C9.M943();
C9.M958();
C9.M944();
C9.M952();
C9.M996();
C9.M992();
C9.M901();
C9.M974();
C8.M859();
}
public static void M859()
{
C9.M923();
C8.M871();
C9.M906();
C9.M936();
C9.M960();
C9.M966();
C9.M996();
C8.M888();
C8.M856();
C8.M860();
}
public static void M860()
{
C9.M976();
C8.M822();
C9.M911();
C9.M944();
C8.M854();
C8.M861();
}
public static void M861()
{
C8.M883();
C8.M862();
}
public static void M862()
{
C8.M834();
C9.M975();
C8.M842();
C8.M863();
}
public static void M863()
{
C8.M821();
C8.M853();
C8.M810();
C9.M963();
C8.M865();
C8.M849();
C9.M920();
C9.M942();
C8.M864();
}
public static void M864()
{
C9.M979();
C9.M969();
C8.M891();
C8.M890();
C8.M865();
}
public static void M865()
{
C9.M995();
C8.M828();
C8.M816();
C9.M965();
C9.M960();
C8.M866();
}
public static void M866()
{
C9.M925();
C8.M808();
C8.M813();
C8.M868();
C8.M832();
C8.M815();
C8.M867();
}
public static void M867()
{
C9.M952();
C9.M913();
C9.M941();
C8.M867();
C9.M997();
C8.M868();
}
public static void M868()
{
C9.M964();
C8.M850();
C8.M853();
C9.M926();
C9.M995();
C9.M901();
C9.M947();
C8.M869();
}
public static void M869()
{
C9.M913();
C8.M827();
C9.M995();
C8.M852();
C8.M821();
C8.M854();
C9.M952();
C8.M804();
C8.M870();
}
public static void M870()
{
C8.M835();
C8.M868();
C8.M815();
C8.M871();
}
public static void M871()
{
C8.M832();
C8.M814();
C8.M840();
C9.M940();
C9.M932();
C8.M851();
C8.M872();
}
public static void M872()
{
C9.M967();
C8.M829();
C9.M936();
C9.M912();
C9.M970();
C9.M935();
C9.M925();
C8.M852();
C8.M873();
}
public static void M873()
{
C8.M900();
C8.M819();
C8.M864();
C8.M814();
C9.M959();
C8.M813();
C9.M980();
C8.M874();
}
public static void M874()
{
C8.M817();
C8.M875();
}
public static void M875()
{
C9.M959();
C8.M876();
}
public static void M876()
{
C9.M948();
C8.M857();
C9.M906();
C9.M998();
C9.M983();
C8.M842();
C9.M932();
C8.M877();
}
public static void M877()
{
C8.M814();
C9.M985();
C8.M878();
}
public static void M878()
{
C8.M850();
C9.M988();
C9.M998();
C8.M879();
}
public static void M879()
{
C8.M890();
C8.M883();
C8.M880();
C8.M884();
}
public static void M880()
{
C8.M900();
C8.M860();
C9.M954();
C8.M817();
C8.M805();
C8.M802();
C8.M881();
}
public static void M881()
{
C8.M820();
C8.M832();
C8.M824();
C9.M924();
C9.M920();
C8.M891();
C8.M821();
C8.M882();
}
public static void M882()
{
C9.M970();
C8.M883();
}
public static void M883()
{
C9.M912();
C9.M985();
C8.M884();
}
public static void M884()
{
C9.M991();
C8.M815();
C9.M930();
C9.M914();
C9.M953();
C8.M885();
}
public static void M885()
{
C8.M825();
C8.M886();
}
public static void M886()
{
C9.M927();
C8.M890();
C9.M932();
C9.M935();
C9.M926();
C8.M832();
C8.M837();
C8.M888();
C8.M887();
}
public static void M887()
{
C8.M890();
C9.M994();
C9.M982();
C8.M888();
C9.M913();
}
public static void M888()
{
C9.M988();
C8.M889();
}
public static void M889()
{
C9.M942();
C9.M958();
C9.M968();
C8.M890();
}
public static void M890()
{
C9.M912();
C8.M861();
C9.M970();
C8.M894();
C9.M988();
C9.M935();
C8.M886();
C9.M929();
C8.M841();
C8.M891();
}
public static void M891()
{
C9.M989();
C9.M976();
C9.M991();
C8.M892();
}
public static void M892()
{
C9.M941();
C8.M891();
C9.M987();
C9.M992();
C8.M859();
C8.M893();
}
public static void M893()
{
C9.M929();
C8.M869();
C9.M938();
C9.M917();
C8.M804();
C8.M806();
C8.M878();
C8.M810();
C9.M940();
C8.M894();
}
public static void M894()
{
C8.M811();
C8.M854();
C8.M855();
C8.M895();
}
public static void M895()
{
C8.M815();
C8.M830();
C9.M961();
C8.M842();
C9.M937();
C8.M895();
C9.M950();
C9.M958();
C8.M861();
C8.M896();
}
public static void M896()
{
C8.M805();
C8.M807();
C8.M897();
}
public static void M897()
{
C8.M822();
C8.M863();
C8.M898();
C8.M873();
C9.M949();
}
public static void M898()
{
C9.M984();
C8.M851();
C8.M844();
C9.M921();
C8.M853();
C8.M899();
}
public static void M899()
{
C9.M983();
C8.M857();
C8.M876();
C9.M987();
C8.M851();
C8.M900();
}
public static void M900()
{
C9.M921();
C8.M813();
C8.M877();
C9.M911();
C9.M928();
C9.M946();
C8.M856();
C9.M901();
}
}
}
