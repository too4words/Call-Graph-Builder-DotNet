using System;

namespace N9
{
public class C9
{
public static void M901()
{
C9.M998();
C9.M911();
C9.M949();
C9.M933();
C9.M955();
C9.M904();
C9.M962();
C9.M984();
C9.M902();
}
public static void M902()
{
C9.M941();
C9.M979();
C9.M970();
C9.M903();
}
public static void M903()
{
C9.M905();
C9.M962();
C9.M935();
C9.M920();
C9.M964();
C9.M933();
C9.M904();
}
public static void M904()
{
C9.M975();
C9.M981();
C9.M982();
C9.M987();
C9.M951();
C9.M905();
}
public static void M905()
{
C9.M990();
C9.M903();
C9.M953();
C9.M909();
C9.M919();
C9.M941();
C9.M906();
}
public static void M906()
{
C9.M956();
C9.M921();
C9.M938();
C9.M988();
C9.M907();
}
public static void M907()
{
C9.M917();
C9.M937();
C9.M949();
C9.M968();
C9.M955();
C9.M983();
C9.M908();
}
public static void M908()
{
C9.M977();
C9.M920();
C9.M953();
C9.M909();
}
public static void M909()
{
C9.M968();
C9.M947();
C9.M993();
C9.M925();
C9.M905();
C9.M917();
C9.M928();
C9.M960();
C9.M910();
}
public static void M910()
{
C9.M951();
C9.M939();
C9.M971();
C9.M981();
C9.M973();
C9.M932();
C9.M961();
C9.M930();
C9.M911();
}
public static void M911()
{
C9.M947();
C9.M941();
C9.M996();
C9.M912();
}
public static void M912()
{
C9.M910();
C9.M916();
C9.M928();
C9.M913();
}
public static void M913()
{
C9.M913();
C9.M927();
C9.M904();
C9.M914();
}
public static void M914()
{
C9.M926();
C9.M944();
C9.M915();
}
public static void M915()
{
C9.M916();
C9.M983();
C9.M960();
C9.M925();
}
public static void M916()
{
C9.M931();
C9.M940();
C9.M917();
}
public static void M917()
{
C9.M976();
C9.M908();
C9.M904();
C9.M977();
C9.M965();
C9.M966();
C9.M993();
C9.M923();
C9.M902();
C9.M918();
}
public static void M918()
{
C9.M971();
C9.M913();
C9.M988();
C9.M938();
C9.M937();
C9.M919();
}
public static void M919()
{
C9.M996();
C9.M977();
C9.M905();
C9.M902();
C9.M957();
C9.M961();
C9.M926();
C9.M994();
C9.M920();
}
public static void M920()
{
C9.M965();
C9.M988();
C9.M970();
C9.M936();
C9.M921();
}
public static void M921()
{
C9.M992();
C9.M908();
C9.M922();
}
public static void M922()
{
C9.M920();
C9.M923();
C9.M906();
C9.M938();
C9.M961();
}
public static void M923()
{
C9.M919();
C9.M904();
C9.M980();
C9.M971();
C9.M972();
C9.M926();
C9.M924();
}
public static void M924()
{
C9.M946();
C9.M923();
C9.M947();
C9.M925();
}
public static void M925()
{
C9.M953();
C9.M936();
C9.M926();
}
public static void M926()
{
C9.M920();
C9.M946();
C9.M977();
C9.M981();
C9.M932();
C9.M901();
C9.M905();
C9.M951();
C9.M985();
C9.M927();
}
public static void M927()
{
C9.M960();
C9.M963();
C9.M964();
C9.M969();
C9.M916();
C9.M932();
C9.M939();
C9.M935();
C9.M928();
}
public static void M928()
{
C9.M984();
C9.M996();
C9.M929();
}
public static void M929()
{
C9.M943();
C9.M953();
C9.M923();
C9.M908();
C9.M939();
C9.M947();
C9.M988();
C9.M930();
}
public static void M930()
{
C9.M940();
C9.M971();
C9.M956();
C9.M998();
C9.M975();
C9.M928();
C9.M929();
C9.M958();
C9.M914();
C9.M931();
}
public static void M931()
{
C9.M993();
C9.M931();
C9.M912();
C9.M909();
C9.M960();
C9.M932();
}
public static void M932()
{
C9.M930();
C9.M990();
C9.M908();
C9.M983();
C9.M935();
C9.M950();
C9.M933();
}
public static void M933()
{
C9.M943();
C9.M904();
C9.M924();
C9.M959();
C9.M925();
C9.M961();
C9.M996();
C9.M991();
C9.M920();
C9.M934();
}
public static void M934()
{
C9.M908();
C9.M969();
C9.M940();
C9.M905();
C9.M982();
C9.M907();
C9.M959();
C9.M970();
C9.M945();
C9.M935();
}
public static void M935()
{
C9.M913();
C9.M942();
C9.M914();
C9.M946();
C9.M982();
C9.M956();
C9.M981();
C9.M911();
C9.M936();
}
public static void M936()
{
C9.M922();
C9.M937();
}
public static void M937()
{
C9.M956();
C9.M972();
C9.M904();
C9.M995();
C9.M905();
C9.M952();
C9.M938();
}
public static void M938()
{
C9.M995();
C9.M938();
C9.M990();
C9.M918();
C9.M952();
C9.M939();
}
public static void M939()
{
C9.M989();
C9.M986();
C9.M924();
C9.M977();
C9.M974();
C9.M978();
C9.M948();
C9.M960();
C9.M940();
}
public static void M940()
{
C9.M981();
C9.M946();
C9.M977();
C9.M947();
C9.M916();
C9.M915();
C9.M969();
C9.M914();
C9.M966();
C9.M941();
}
public static void M941()
{
C9.M986();
C9.M942();
}
public static void M942()
{
C9.M962();
C9.M943();
}
public static void M943()
{
C9.M997();
C9.M985();
C9.M944();
}
public static void M944()
{
C9.M950();
C9.M995();
C9.M992();
C9.M923();
C9.M969();
C9.M957();
C9.M933();
C9.M945();
}
public static void M945()
{
C9.M942();
C9.M914();
C9.M994();
C9.M946();
}
public static void M946()
{
C9.M921();
C9.M950();
C9.M927();
C9.M919();
C9.M905();
C9.M901();
C9.M980();
C9.M956();
C9.M947();
}
public static void M947()
{
C9.M947();
C9.M907();
C9.M971();
C9.M924();
C9.M985();
C9.M937();
C9.M975();
C9.M948();
}
public static void M948()
{
C9.M960();
C9.M950();
C9.M949();
}
public static void M949()
{
C9.M917();
C9.M932();
C9.M950();
C9.M983();
C9.M981();
C9.M925();
C9.M977();
}
public static void M950()
{
C9.M948();
C9.M983();
C9.M927();
C9.M932();
C9.M919();
C9.M984();
C9.M951();
}
public static void M951()
{
C9.M936();
C9.M974();
C9.M944();
C9.M914();
C9.M997();
C9.M905();
C9.M918();
C9.M972();
C9.M952();
}
public static void M952()
{
C9.M986();
C9.M925();
C9.M998();
C9.M982();
C9.M920();
C9.M953();
}
public static void M953()
{
C9.M919();
C9.M981();
C9.M962();
C9.M920();
C9.M965();
C9.M988();
C9.M954();
}
public static void M954()
{
C9.M943();
C9.M955();
}
public static void M955()
{
C9.M979();
C9.M922();
C9.M924();
C9.M908();
C9.M956();
}
public static void M956()
{
C9.M921();
C9.M973();
C9.M953();
C9.M938();
C9.M907();
C9.M901();
C9.M902();
C9.M966();
C9.M946();
C9.M957();
}
public static void M957()
{
C9.M970();
C9.M997();
C9.M958();
C9.M902();
C9.M995();
}
public static void M958()
{
C9.M925();
C9.M994();
C9.M937();
C9.M989();
C9.M965();
C9.M944();
C9.M959();
}
public static void M959()
{
C9.M997();
C9.M919();
C9.M989();
C9.M936();
C9.M932();
C9.M908();
C9.M934();
C9.M960();
}
public static void M960()
{
C9.M979();
C9.M910();
C9.M980();
C9.M928();
C9.M913();
C9.M971();
C9.M960();
C9.M961();
}
public static void M961()
{
C9.M920();
C9.M956();
C9.M951();
C9.M936();
C9.M911();
C9.M949();
C9.M966();
C9.M962();
}
public static void M962()
{
C9.M997();
C9.M946();
C9.M979();
C9.M963();
}
public static void M963()
{
C9.M927();
C9.M985();
C9.M917();
C9.M926();
C9.M976();
C9.M964();
}
public static void M964()
{
C9.M954();
C9.M965();
}
public static void M965()
{
C9.M917();
C9.M964();
C9.M966();
}
public static void M966()
{
C9.M958();
C9.M912();
C9.M975();
C9.M989();
C9.M988();
C9.M976();
C9.M973();
C9.M967();
}
public static void M967()
{
C9.M984();
C9.M964();
C9.M919();
C9.M918();
C9.M934();
C9.M915();
C9.M908();
C9.M958();
C9.M968();
}
public static void M968()
{
C9.M952();
C9.M959();
C9.M937();
C9.M984();
C9.M928();
C9.M969();
}
public static void M969()
{
C9.M948();
C9.M993();
C9.M991();
C9.M955();
C9.M951();
C9.M908();
C9.M917();
C9.M941();
C9.M970();
}
public static void M970()
{
C9.M954();
C9.M986();
C9.M991();
C9.M924();
C9.M934();
C9.M958();
C9.M971();
}
public static void M971()
{
C9.M953();
C9.M925();
C9.M961();
C9.M993();
C9.M989();
C9.M909();
C9.M968();
C9.M972();
}
public static void M972()
{
C9.M911();
C9.M968();
C9.M946();
C9.M906();
C9.M966();
C9.M956();
C9.M927();
C9.M983();
C9.M973();
}
public static void M973()
{
C9.M932();
C9.M928();
C9.M995();
C9.M974();
}
public static void M974()
{
C9.M922();
C9.M923();
C9.M975();
C9.M968();
C9.M958();
C9.M962();
C9.M947();
C9.M983();
C9.M924();
}
public static void M975()
{
C9.M974();
C9.M907();
C9.M913();
C9.M924();
C9.M933();
C9.M989();
C9.M940();
C9.M926();
C9.M910();
C9.M976();
}
public static void M976()
{
C9.M981();
C9.M961();
C9.M911();
C9.M974();
C9.M904();
C9.M977();
}
public static void M977()
{
C9.M903();
C9.M960();
C9.M990();
C9.M978();
}
public static void M978()
{
C9.M962();
C9.M979();
}
public static void M979()
{
C9.M931();
C9.M902();
C9.M984();
C9.M926();
C9.M966();
C9.M949();
C9.M906();
C9.M935();
C9.M980();
}
public static void M980()
{
C9.M983();
C9.M922();
C9.M916();
C9.M990();
C9.M950();
C9.M914();
C9.M960();
C9.M996();
C9.M981();
}
public static void M981()
{
C9.M987();
C9.M970();
C9.M985();
C9.M976();
C9.M982();
}
public static void M982()
{
C9.M915();
C9.M958();
C9.M948();
C9.M955();
C9.M983();
}
public static void M983()
{
C9.M944();
C9.M961();
C9.M991();
C9.M918();
C9.M984();
}
public static void M984()
{
C9.M992();
C9.M974();
C9.M911();
C9.M985();
}
public static void M985()
{
C9.M908();
C9.M923();
C9.M989();
C9.M920();
C9.M986();
}
public static void M986()
{
C9.M956();
C9.M996();
C9.M939();
C9.M993();
C9.M982();
C9.M953();
C9.M914();
C9.M987();
}
public static void M987()
{
C9.M963();
C9.M949();
C9.M918();
C9.M991();
C9.M988();
}
public static void M988()
{
C9.M954();
C9.M961();
C9.M969();
C9.M966();
C9.M918();
C9.M993();
C9.M970();
C9.M989();
C9.M926();
}
public static void M989()
{
C9.M904();
C9.M988();
C9.M996();
C9.M974();
C9.M922();
C9.M919();
C9.M997();
C9.M950();
C9.M912();
C9.M990();
}
public static void M990()
{
C9.M942();
C9.M974();
C9.M991();
}
public static void M991()
{
C9.M964();
C9.M903();
C9.M921();
C9.M902();
C9.M997();
C9.M943();
C9.M992();
}
public static void M992()
{
C9.M935();
C9.M996();
C9.M921();
C9.M949();
C9.M967();
C9.M941();
C9.M906();
C9.M994();
C9.M983();
C9.M993();
}
public static void M993()
{
C9.M906();
C9.M935();
C9.M905();
C9.M994();
}
public static void M994()
{
C9.M977();
C9.M911();
C9.M921();
C9.M973();
C9.M930();
C9.M920();
C9.M941();
C9.M983();
C9.M995();
}
public static void M995()
{
C9.M919();
C9.M993();
C9.M903();
C9.M953();
C9.M996();
}
public static void M996()
{
C9.M949();
C9.M987();
C9.M928();
C9.M905();
C9.M953();
C9.M998();
C9.M948();
C9.M914();
C9.M903();
C9.M997();
}
public static void M997()
{
C9.M927();
C9.M998();
}
public static void M998()
{
C9.M937();
C9.M940();
C9.M959();
C9.M979();
C9.M924();
C9.M911();
C9.M980();
C9.M925();
C9.M913();
C9.M999();
}
public static void M999()
{
C9.M993();
C9.M914();
C9.M986();
C9.M930();
C9.M972();
C9.M938();
C9.M951();
C9.M904();
}
}
}
