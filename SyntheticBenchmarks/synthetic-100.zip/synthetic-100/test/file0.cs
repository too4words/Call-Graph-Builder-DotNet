using N1;
using N2;
using N3;
using N4;
using System;

namespace N0
{
public class C0
{
public static void M1()
{
C3.M73();
C3.M79();
C4.M93();
C2.M44();
C0.M14();
C4.M95();
C0.M2();
}
public static void M2()
{
C2.M50();
C4.M91();
C4.M93();
C1.M21();
C2.M47();
C1.M31();
C0.M3();
}
public static void M3()
{
C0.M13();
C0.M14();
C2.M41();
C4.M83();
C0.M9();
C2.M43();
C0.M5();
C0.M4();
}
public static void M4()
{
C4.M82();
C0.M13();
C2.M49();
C0.M5();
C0.M3();
}
public static void M5()
{
C4.M94();
C4.M90();
C2.M49();
C4.M85();
C4.M86();
C4.M81();
C2.M56();
C0.M6();
}
public static void M6()
{
C1.M30();
C0.M5();
C3.M69();
C0.M19();
C0.M7();
}
public static void M7()
{
C2.M59();
C4.M84();
C3.M80();
C0.M8();
}
public static void M8()
{
C2.M57();
C1.M31();
C2.M51();
C2.M47();
C4.M92();
C0.M8();
C2.M52();
C0.M9();
}
public static void M9()
{
C1.M24();
C4.M96();
C3.M80();
C4.M93();
C0.M10();
C2.M54();
}
public static void M10()
{
C2.M44();
C0.M11();
}
public static void M11()
{
C2.M60();
C2.M48();
C4.M90();
C1.M26();
C0.M12();
}
public static void M12()
{
C0.M1();
C2.M54();
C0.M4();
C3.M73();
C4.M85();
C1.M27();
C0.M13();
}
public static void M13()
{
C1.M28();
C3.M68();
C1.M34();
C0.M14();
}
public static void M14()
{
C2.M45();
C2.M44();
C2.M56();
C3.M78();
C1.M35();
C0.M15();
}
public static void M15()
{
C2.M57();
C4.M88();
C0.M16();
}
public static void M16()
{
C2.M47();
C0.M20();
C0.M11();
C4.M87();
C3.M63();
C1.M23();
C0.M15();
C0.M17();
}
public static void M17()
{
C1.M21();
C3.M66();
C0.M5();
C4.M92();
C2.M47();
C0.M18();
}
public static void M18()
{
C0.M4();
C3.M77();
C3.M74();
C4.M95();
C0.M19();
}
public static void M19()
{
C2.M52();
C1.M26();
C3.M75();
C2.M49();
C1.M35();
C0.M10();
C2.M56();
C0.M20();
}
public static void M20()
{
C2.M55();
C1.M25();
C1.M28();
C1.M33();
C1.M37();
C4.M82();
C2.M52();
C1.M34();
C1.M21();
}
public static void Main(string[] args)
{
C0.M1();
}
}
}
