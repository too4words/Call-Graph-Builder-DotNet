using N2;
using N3;
using N4;
using System;

namespace N1
{
public class C1
{
public static void M21()
{
C4.M87();
C1.M38();
C1.M23();
C1.M27();
C4.M81();
C2.M58();
C1.M31();
C2.M53();
C3.M61();
C1.M22();
}
public static void M22()
{
C1.M34();
C3.M79();
C3.M65();
C2.M56();
C3.M68();
C1.M32();
C1.M38();
C1.M37();
C2.M55();
C1.M23();
}
public static void M23()
{
C3.M62();
C3.M73();
C2.M41();
C4.M94();
C4.M95();
C4.M93();
C1.M24();
}
public static void M24()
{
C3.M73();
C1.M29();
C4.M94();
C1.M25();
}
public static void M25()
{
C1.M29();
C1.M26();
}
public static void M26()
{
C3.M62();
C4.M93();
C3.M71();
C3.M79();
C4.M81();
C3.M69();
C3.M76();
C4.M94();
C3.M66();
C1.M27();
}
public static void M27()
{
C3.M76();
C4.M84();
C3.M74();
C4.M85();
C1.M38();
C3.M68();
C1.M28();
}
public static void M28()
{
C4.M90();
C2.M45();
C3.M74();
C1.M29();
}
public static void M29()
{
C4.M85();
C4.M86();
C3.M62();
C1.M37();
C1.M30();
}
public static void M30()
{
C3.M78();
C2.M53();
C1.M22();
C1.M30();
C3.M70();
C1.M31();
}
public static void M31()
{
C4.M93();
C3.M74();
C2.M59();
C2.M57();
C2.M54();
C4.M85();
C1.M32();
}
public static void M32()
{
C3.M67();
C4.M95();
C1.M26();
C3.M64();
C1.M31();
C2.M41();
C1.M28();
C3.M69();
C2.M56();
C1.M33();
}
public static void M33()
{
C3.M70();
C1.M32();
C4.M83();
C3.M69();
C4.M87();
C1.M34();
}
public static void M34()
{
C4.M85();
C4.M92();
C1.M40();
C2.M53();
C2.M41();
C1.M36();
C1.M35();
}
public static void M35()
{
C3.M66();
C1.M34();
C1.M36();
}
public static void M36()
{
C4.M91();
C1.M37();
}
public static void M37()
{
C3.M77();
C1.M38();
}
public static void M38()
{
C4.M89();
C1.M26();
C1.M39();
}
public static void M39()
{
C3.M77();
C2.M44();
C2.M41();
C3.M75();
C1.M40();
}
public static void M40()
{
C1.M29();
C4.M85();
C2.M43();
C2.M41();
}
}
}
