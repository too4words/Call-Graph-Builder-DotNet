using N3;
using N4;
using System;

namespace N2
{
public class C2
{
public static void M41()
{
C3.M63();
C4.M97();
C4.M88();
C2.M41();
C2.M45();
C2.M48();
C3.M79();
C3.M73();
C2.M51();
C2.M42();
}
public static void M42()
{
C3.M77();
C3.M63();
C4.M86();
C3.M69();
C2.M43();
}
public static void M43()
{
C4.M96();
C2.M52();
C3.M74();
C4.M83();
C3.M61();
C4.M84();
C2.M45();
C3.M63();
C4.M92();
C2.M44();
}
public static void M44()
{
C2.M56();
C3.M73();
C2.M45();
}
public static void M45()
{
C4.M98();
C2.M58();
C2.M46();
}
public static void M46()
{
C4.M94();
C2.M55();
C2.M52();
C3.M75();
C2.M47();
}
public static void M47()
{
C2.M43();
C4.M89();
C4.M93();
C2.M44();
C2.M48();
}
public static void M48()
{
C4.M81();
C3.M79();
C4.M85();
C2.M60();
C4.M95();
C4.M88();
C2.M49();
}
public static void M49()
{
C4.M84();
C2.M44();
C4.M93();
C2.M50();
}
public static void M50()
{
C3.M73();
C3.M78();
C4.M93();
C2.M51();
}
public static void M51()
{
C2.M47();
C4.M96();
C4.M91();
C2.M60();
C2.M52();
}
public static void M52()
{
C2.M47();
C2.M52();
C2.M53();
}
public static void M53()
{
C3.M71();
C2.M58();
C3.M62();
C3.M76();
C2.M50();
C2.M54();
}
public static void M54()
{
C3.M80();
C3.M79();
C4.M85();
C2.M43();
C2.M55();
}
public static void M55()
{
C3.M76();
C3.M73();
C2.M51();
C3.M66();
C2.M56();
}
public static void M56()
{
C3.M68();
C4.M94();
C3.M64();
C2.M57();
}
public static void M57()
{
C3.M61();
C3.M80();
C2.M58();
}
public static void M58()
{
C4.M81();
C4.M94();
C4.M91();
C2.M43();
C4.M96();
C2.M55();
C2.M59();
}
public static void M59()
{
C3.M73();
C3.M74();
C4.M90();
C3.M65();
C3.M71();
C2.M60();
}
public static void M60()
{
C2.M49();
C4.M93();
C3.M72();
C3.M74();
C4.M92();
C4.M87();
C3.M75();
C3.M69();
C4.M88();
C3.M61();
}
}
}
