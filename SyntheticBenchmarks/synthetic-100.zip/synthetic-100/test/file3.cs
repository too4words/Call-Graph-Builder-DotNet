using N4;
using System;

namespace N3
{
public class C3
{
public static void M61()
{
C4.M90();
C3.M76();
C4.M92();
C4.M93();
C3.M70();
C3.M62();
}
public static void M62()
{
C3.M61();
C3.M65();
C4.M93();
C4.M89();
C4.M86();
C4.M87();
C3.M69();
C3.M63();
}
public static void M63()
{
C4.M85();
C4.M88();
C3.M80();
C4.M81();
C4.M93();
C3.M64();
}
public static void M64()
{
C4.M88();
C3.M65();
}
public static void M65()
{
C4.M96();
C3.M74();
C3.M73();
C3.M62();
C4.M93();
C4.M84();
C3.M78();
C3.M66();
}
public static void M66()
{
C4.M97();
C3.M69();
C3.M64();
C3.M75();
C4.M84();
C3.M65();
C3.M70();
C4.M93();
C3.M67();
}
public static void M67()
{
C4.M88();
C4.M82();
C4.M90();
C3.M69();
C3.M78();
C4.M86();
C3.M68();
}
public static void M68()
{
C4.M96();
C3.M69();
}
public static void M69()
{
C3.M71();
C3.M63();
C3.M70();
}
public static void M70()
{
C4.M90();
C4.M92();
C3.M61();
C3.M79();
C3.M78();
C4.M81();
C3.M71();
}
public static void M71()
{
C4.M93();
C3.M76();
C4.M86();
C3.M72();
}
public static void M72()
{
C4.M90();
C3.M78();
C4.M83();
C4.M93();
C3.M75();
C3.M61();
C3.M66();
C3.M71();
C3.M79();
C3.M73();
}
public static void M73()
{
C3.M68();
C3.M66();
C4.M94();
C3.M74();
C4.M91();
C4.M86();
C3.M71();
C4.M83();
C3.M73();
}
public static void M74()
{
C3.M64();
C3.M66();
C4.M86();
C4.M93();
C3.M61();
C3.M75();
}
public static void M75()
{
C3.M67();
C3.M63();
C4.M84();
C4.M98();
C4.M90();
C4.M93();
C4.M92();
C4.M85();
C4.M96();
C3.M76();
}
public static void M76()
{
C3.M66();
C4.M91();
C4.M83();
C3.M72();
C4.M93();
C4.M92();
C3.M77();
}
public static void M77()
{
C3.M73();
C4.M85();
C4.M94();
C3.M62();
C3.M78();
}
public static void M78()
{
C3.M76();
C3.M74();
C4.M94();
C4.M93();
C3.M70();
C3.M72();
C4.M96();
C3.M79();
}
public static void M79()
{
C3.M70();
C3.M62();
C3.M72();
C3.M80();
}
public static void M80()
{
C4.M83();
C3.M66();
C3.M74();
C3.M61();
C3.M80();
C4.M89();
C4.M86();
C3.M78();
C3.M64();
C4.M81();
}
}
}
