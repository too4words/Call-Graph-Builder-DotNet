using System;

namespace N4
{
public class C4
{
public static void M81()
{
C4.M81();
C4.M93();
C4.M85();
C4.M95();
C4.M87();
C4.M84();
C4.M83();
C4.M98();
C4.M89();
C4.M82();
}
public static void M82()
{
C4.M85();
C4.M83();
C4.M97();
C4.M92();
C4.M90();
C4.M87();
}
public static void M83()
{
C4.M93();
C4.M84();
}
public static void M84()
{
C4.M90();
C4.M91();
C4.M98();
C4.M97();
C4.M85();
C4.M84();
C4.M92();
C4.M87();
}
public static void M85()
{
C4.M98();
C4.M93();
C4.M97();
C4.M95();
C4.M96();
C4.M84();
C4.M92();
C4.M81();
C4.M82();
C4.M86();
}
public static void M86()
{
C4.M82();
C4.M83();
C4.M96();
C4.M85();
C4.M87();
C4.M81();
}
public static void M87()
{
C4.M88();
C4.M81();
C4.M95();
C4.M93();
C4.M91();
}
public static void M88()
{
C4.M88();
C4.M82();
C4.M94();
C4.M81();
C4.M92();
C4.M89();
}
public static void M89()
{
C4.M91();
C4.M95();
C4.M81();
C4.M89();
C4.M90();
}
public static void M90()
{
C4.M87();
C4.M86();
C4.M81();
C4.M88();
C4.M97();
C4.M98();
C4.M82();
C4.M95();
C4.M89();
C4.M91();
}
public static void M91()
{
C4.M92();
C4.M97();
}
public static void M92()
{
C4.M90();
C4.M85();
C4.M93();
}
public static void M93()
{
C4.M82();
C4.M85();
C4.M93();
C4.M86();
C4.M94();
}
public static void M94()
{
C4.M89();
C4.M83();
C4.M96();
C4.M95();
}
public static void M95()
{
C4.M89();
C4.M96();
}
public static void M96()
{
C4.M90();
C4.M87();
C4.M97();
}
public static void M97()
{
C4.M87();
C4.M98();
}
public static void M98()
{
C4.M98();
C4.M93();
C4.M88();
C4.M99();
}
public static void M99()
{
C4.M82();
C4.M90();
C4.M94();
C4.M97();
C4.M95();
C4.M83();
C4.M89();
C4.M96();
C4.M87();
}
}
}
