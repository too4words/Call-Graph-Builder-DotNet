using N1;
using N2;
using N3;
using N4;
using N5;
using N6;
using N7;
using N8;
using N9;
using System;

namespace N0
{
public class C0
{
public static void M1()
{
C3.M390();
C2.M250();
C0.M86();
C3.M359();
C4.M432();
C1.M103();
C0.M2();
}
public static void M2()
{
C5.M550();
C0.M47();
C2.M242();
C5.M567();
C1.M181();
C3.M377();
C1.M145();
C2.M203();
C0.M3();
}
public static void M3()
{
C5.M503();
C7.M764();
C8.M897();
C1.M148();
C0.M4();
}
public static void M4()
{
C3.M351();
C6.M666();
C3.M319();
C8.M869();
C9.M906();
C8.M839();
C7.M708();
C6.M629();
C4.M448();
C0.M5();
}
public static void M5()
{
C4.M436();
C0.M6();
}
public static void M6()
{
C8.M808();
C2.M296();
C0.M7();
}
public static void M7()
{
C5.M518();
C0.M74();
C2.M246();
C5.M583();
C0.M8();
}
public static void M8()
{
C4.M432();
C0.M20();
C8.M806();
C1.M108();
C1.M134();
C5.M564();
C8.M886();
C5.M543();
C1.M178();
C0.M9();
}
public static void M9()
{
C6.M627();
C9.M977();
C2.M205();
C6.M688();
C0.M10();
}
public static void M10()
{
C5.M582();
C0.M11();
}
public static void M11()
{
C4.M488();
C5.M525();
C2.M263();
C0.M70();
C9.M919();
C5.M597();
C1.M184();
C0.M12();
}
public static void M12()
{
C9.M988();
C5.M568();
C0.M13();
}
public static void M13()
{
C7.M797();
C8.M875();
C4.M430();
C5.M518();
C3.M315();
C2.M221();
C5.M507();
C3.M331();
C0.M14();
}
public static void M14()
{
C2.M212();
C7.M736();
C3.M342();
C9.M951();
C1.M165();
C4.M452();
C0.M43();
C4.M430();
C0.M15();
}
public static void M15()
{
C9.M985();
C1.M121();
C2.M256();
C8.M821();
C7.M751();
C0.M16();
}
public static void M16()
{
C7.M720();
C3.M321();
C8.M856();
C5.M512();
C4.M422();
C6.M622();
C0.M17();
}
public static void M17()
{
C1.M145();
C9.M994();
C0.M39();
C7.M745();
C3.M301();
C9.M975();
C1.M110();
C6.M663();
C9.M983();
C0.M18();
}
public static void M18()
{
C7.M707();
C7.M722();
C0.M19();
}
public static void M19()
{
C7.M751();
C1.M183();
C3.M310();
C9.M904();
C4.M468();
C0.M20();
}
public static void M20()
{
C7.M753();
C6.M671();
C0.M4();
C4.M448();
C5.M592();
C0.M21();
}
public static void M21()
{
C1.M125();
C8.M844();
C7.M796();
C9.M992();
C3.M363();
C9.M994();
C9.M908();
C2.M237();
C2.M234();
C0.M22();
}
public static void M22()
{
C3.M347();
C9.M913();
C4.M418();
C1.M152();
C0.M66();
C3.M321();
C0.M23();
}
public static void M23()
{
C0.M2();
C9.M938();
C5.M548();
C0.M99();
C1.M197();
C8.M832();
C5.M538();
C0.M11();
C0.M24();
}
public static void M24()
{
C0.M44();
C8.M865();
C8.M868();
C3.M305();
C1.M141();
C5.M547();
C4.M446();
C7.M769();
C1.M176();
C0.M25();
}
public static void M25()
{
C3.M312();
C6.M669();
C0.M26();
}
public static void M26()
{
C1.M185();
C7.M797();
C4.M486();
C3.M321();
C1.M160();
C8.M835();
C0.M27();
}
public static void M27()
{
C4.M486();
C3.M316();
C4.M489();
C4.M432();
C0.M28();
}
public static void M28()
{
C0.M2();
C5.M508();
C0.M44();
C8.M875();
C9.M926();
C0.M12();
C2.M259();
C9.M982();
C0.M29();
}
public static void M29()
{
C9.M951();
C0.M43();
C3.M367();
C9.M928();
C0.M30();
}
public static void M30()
{
C7.M798();
C4.M468();
C6.M648();
C9.M974();
C9.M933();
C0.M31();
}
public static void M31()
{
C1.M126();
C0.M32();
}
public static void M32()
{
C7.M753();
C7.M749();
C6.M612();
C8.M875();
C0.M33();
}
public static void M33()
{
C7.M701();
C6.M614();
C4.M466();
C7.M726();
C3.M377();
C4.M437();
C4.M428();
C0.M34();
}
public static void M34()
{
C0.M40();
C4.M402();
C0.M35();
}
public static void M35()
{
C2.M248();
C1.M121();
C0.M54();
C6.M686();
C2.M211();
C2.M233();
C7.M755();
C1.M119();
C3.M392();
C0.M36();
}
public static void M36()
{
C0.M37();
C9.M926();
C8.M836();
C3.M341();
C5.M554();
C4.M423();
C7.M750();
}
public static void M37()
{
C7.M753();
C2.M294();
C2.M264();
C0.M52();
C3.M337();
C5.M556();
C0.M38();
}
public static void M38()
{
C9.M942();
C2.M225();
C6.M665();
C9.M929();
C0.M39();
}
public static void M39()
{
C3.M311();
C7.M759();
C0.M66();
C7.M754();
C7.M726();
C0.M40();
}
public static void M40()
{
C9.M954();
C4.M439();
C1.M169();
C5.M520();
C9.M993();
C4.M494();
C4.M483();
C9.M963();
C0.M41();
}
public static void M41()
{
C6.M686();
C6.M628();
C3.M386();
C8.M821();
C0.M14();
C6.M677();
C0.M42();
}
public static void M42()
{
C2.M285();
C1.M109();
C6.M629();
C1.M196();
C7.M782();
C0.M43();
}
public static void M43()
{
C3.M318();
C2.M268();
C0.M9();
C0.M91();
C1.M189();
C0.M44();
}
public static void M44()
{
C3.M398();
C2.M277();
C8.M861();
C0.M82();
C6.M613();
C7.M740();
C4.M467();
C3.M312();
C4.M451();
C0.M45();
}
public static void M45()
{
C2.M300();
C7.M769();
C5.M568();
C0.M46();
}
public static void M46()
{
C8.M890();
C6.M680();
C3.M314();
C8.M837();
C0.M47();
}
public static void M47()
{
C9.M915();
C8.M822();
C7.M791();
C4.M474();
C9.M956();
C1.M126();
C5.M530();
C0.M31();
C0.M48();
}
public static void M48()
{
C1.M121();
C8.M900();
C5.M512();
C9.M903();
C3.M305();
C0.M49();
}
public static void M49()
{
C5.M566();
C3.M388();
C8.M824();
C5.M546();
C7.M771();
C0.M82();
C0.M50();
}
public static void M50()
{
C3.M365();
C0.M68();
C0.M52();
C8.M808();
C8.M859();
C0.M51();
}
public static void M51()
{
C4.M410();
C6.M604();
C6.M636();
C9.M952();
C1.M171();
C2.M247();
C0.M52();
}
public static void M52()
{
C0.M69();
C6.M606();
C8.M801();
C0.M53();
}
public static void M53()
{
C9.M955();
C0.M83();
C7.M709();
C0.M9();
C1.M191();
C5.M549();
C7.M721();
C3.M395();
C4.M464();
C0.M54();
}
public static void M54()
{
C8.M805();
C5.M503();
C8.M855();
C7.M766();
C0.M66();
C7.M761();
C3.M370();
C4.M457();
C7.M724();
C0.M55();
}
public static void M55()
{
C1.M148();
C2.M266();
C9.M901();
C6.M620();
C0.M56();
}
public static void M56()
{
C4.M483();
C9.M947();
C3.M342();
C6.M656();
C0.M32();
C5.M523();
C9.M959();
C5.M585();
C0.M57();
}
public static void M57()
{
C5.M590();
C6.M689();
C3.M371();
C5.M537();
C1.M175();
C5.M517();
C3.M330();
C4.M413();
C3.M395();
C0.M58();
}
public static void M58()
{
C6.M603();
C1.M101();
C7.M780();
C1.M186();
C1.M105();
C4.M485();
C0.M59();
}
public static void M59()
{
C6.M611();
C8.M881();
C3.M378();
C7.M756();
C6.M689();
C1.M180();
C0.M89();
C1.M154();
C7.M706();
C0.M60();
}
public static void M60()
{
C3.M380();
C7.M738();
C4.M432();
C4.M453();
C8.M845();
C9.M916();
C0.M61();
}
public static void M61()
{
C1.M177();
C3.M376();
C3.M390();
C8.M831();
C2.M282();
C2.M207();
C0.M94();
C7.M734();
C8.M870();
C0.M62();
}
public static void M62()
{
C0.M17();
C7.M753();
C7.M702();
C0.M63();
}
public static void M63()
{
C2.M237();
C1.M172();
C1.M129();
C9.M910();
C0.M78();
C2.M207();
C1.M164();
C0.M64();
}
public static void M64()
{
C5.M509();
C2.M282();
C3.M384();
C4.M467();
C9.M914();
C9.M948();
C6.M674();
C9.M961();
C1.M199();
C0.M65();
}
public static void M65()
{
C1.M183();
C8.M844();
C0.M9();
C7.M727();
C0.M95();
C0.M71();
C3.M329();
C0.M66();
}
public static void M66()
{
C2.M284();
C0.M22();
C8.M817();
C9.M928();
C0.M72();
C3.M399();
C0.M5();
C0.M67();
}
public static void M67()
{
C1.M143();
C5.M566();
C3.M304();
C5.M541();
C7.M767();
C7.M710();
C7.M771();
C2.M275();
C0.M68();
}
public static void M68()
{
C1.M108();
C4.M448();
C8.M814();
C2.M291();
C1.M144();
C0.M61();
C9.M908();
C0.M52();
C0.M69();
}
public static void M69()
{
C5.M570();
C8.M856();
C7.M753();
C0.M70();
}
public static void M70()
{
C0.M78();
C0.M59();
C5.M581();
C4.M403();
C9.M922();
C0.M71();
}
public static void M71()
{
C0.M83();
C5.M579();
C0.M72();
}
public static void M72()
{
C9.M983();
C4.M463();
C0.M73();
}
public static void M73()
{
C8.M806();
C0.M74();
}
public static void M74()
{
C6.M658();
C0.M75();
}
public static void M75()
{
C9.M988();
C4.M472();
C0.M74();
C7.M733();
C8.M859();
C9.M985();
C0.M76();
}
public static void M76()
{
C5.M514();
C3.M383();
C1.M140();
C9.M960();
C9.M908();
C8.M877();
C0.M77();
}
public static void M77()
{
C8.M828();
C1.M147();
C0.M84();
C6.M633();
C4.M489();
C2.M245();
C9.M958();
C3.M365();
C0.M78();
}
public static void M78()
{
C6.M629();
C1.M193();
C2.M288();
C8.M896();
C4.M463();
C3.M352();
C2.M214();
C3.M337();
C0.M79();
}
public static void M79()
{
C2.M250();
C3.M395();
C2.M270();
C0.M98();
C7.M783();
C0.M21();
C6.M648();
C0.M91();
C4.M436();
C0.M80();
}
public static void M80()
{
C0.M21();
C0.M81();
}
public static void M81()
{
C1.M181();
C1.M173();
C7.M701();
C3.M398();
C1.M156();
C3.M316();
C9.M992();
C1.M174();
C0.M82();
}
public static void M82()
{
C4.M413();
C6.M696();
C6.M623();
C6.M684();
C4.M443();
C5.M540();
C0.M83();
}
public static void M83()
{
C0.M89();
C1.M159();
C1.M162();
C1.M169();
C8.M802();
C0.M9();
C0.M84();
}
public static void M84()
{
C4.M483();
C5.M541();
C7.M730();
C3.M363();
C0.M64();
C9.M983();
C0.M85();
}
public static void M85()
{
C8.M808();
C8.M890();
C3.M344();
C0.M6();
C0.M86();
}
public static void M86()
{
C0.M20();
C5.M586();
C4.M499();
C3.M308();
C0.M37();
C0.M87();
}
public static void M87()
{
C1.M163();
C3.M334();
C0.M88();
}
public static void M88()
{
C6.M697();
C6.M645();
C4.M413();
C3.M341();
C4.M479();
C0.M76();
C0.M2();
C2.M277();
C0.M89();
}
public static void M89()
{
C8.M850();
C9.M978();
C1.M172();
C5.M513();
C2.M219();
C8.M855();
C4.M425();
C9.M952();
C9.M929();
C0.M90();
}
public static void M90()
{
C2.M220();
C6.M604();
C0.M91();
}
public static void M91()
{
C2.M280();
C6.M679();
C9.M992();
C5.M521();
C9.M985();
C5.M589();
C8.M850();
C1.M126();
C0.M92();
}
public static void M92()
{
C6.M639();
C6.M674();
C8.M821();
C7.M784();
C8.M894();
C3.M317();
C0.M22();
C5.M583();
C9.M908();
C0.M93();
}
public static void M93()
{
C5.M531();
C9.M984();
C4.M493();
C0.M26();
C0.M94();
}
public static void M94()
{
C5.M505();
C3.M367();
C6.M643();
C0.M95();
}
public static void M95()
{
C0.M83();
C2.M289();
C9.M973();
C1.M114();
C2.M232();
C8.M891();
C3.M366();
C7.M732();
C0.M96();
}
public static void M96()
{
C9.M957();
C0.M89();
C4.M412();
C4.M426();
C0.M97();
}
public static void M97()
{
C8.M900();
C3.M339();
C4.M497();
C6.M691();
C4.M433();
C9.M959();
C1.M108();
C9.M930();
C0.M98();
}
public static void M98()
{
C2.M280();
C8.M822();
C0.M74();
C8.M819();
C0.M99();
}
public static void M99()
{
C6.M654();
C7.M715();
C0.M16();
C6.M618();
C9.M944();
C9.M967();
C0.M43();
C6.M660();
C0.M100();
}
public static void M100()
{
C5.M560();
C5.M590();
C8.M892();
C5.M529();
C5.M584();
C6.M674();
C1.M101();
}
public static void Main(string[] args)
{
C0.M1();
}
}
}
