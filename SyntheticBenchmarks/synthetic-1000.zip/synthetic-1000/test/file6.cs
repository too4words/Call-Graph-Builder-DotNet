using N7;
using N8;
using N9;
using System;

namespace N6
{
public class C6
{
public static void M601()
{
C9.M976();
C8.M842();
C8.M827();
C9.M944();
C7.M779();
C9.M949();
C7.M703();
C7.M750();
C9.M912();
C6.M602();
}
public static void M602()
{
C8.M805();
C6.M697();
C7.M787();
C7.M785();
C9.M924();
C6.M647();
C6.M603();
}
public static void M603()
{
C7.M715();
C6.M653();
C8.M808();
C8.M870();
C6.M670();
C7.M708();
C6.M683();
C9.M945();
C6.M604();
}
public static void M604()
{
C8.M845();
C6.M669();
C7.M751();
C7.M792();
C8.M879();
C7.M714();
C8.M894();
C8.M872();
C9.M906();
C6.M605();
}
public static void M605()
{
C9.M924();
C6.M656();
C6.M677();
C6.M601();
C8.M855();
C6.M606();
}
public static void M606()
{
C8.M858();
C6.M601();
C7.M715();
C9.M916();
C7.M756();
C6.M655();
C6.M607();
}
public static void M607()
{
C6.M684();
C7.M748();
C6.M675();
C6.M602();
C8.M830();
C6.M608();
}
public static void M608()
{
C9.M906();
C7.M735();
C6.M609();
}
public static void M609()
{
C9.M998();
C7.M790();
C7.M705();
C6.M634();
C6.M610();
}
public static void M610()
{
C7.M721();
C9.M955();
C6.M692();
C8.M801();
C9.M913();
C8.M877();
C7.M728();
C8.M855();
C6.M638();
C6.M611();
}
public static void M611()
{
C9.M952();
C6.M635();
C6.M612();
}
public static void M612()
{
C7.M708();
C9.M966();
C6.M629();
C8.M833();
C7.M791();
C6.M613();
}
public static void M613()
{
C6.M667();
C6.M644();
C8.M804();
C7.M712();
C6.M665();
C7.M787();
C6.M614();
}
public static void M614()
{
C6.M662();
C7.M780();
C6.M656();
C8.M886();
C8.M895();
C8.M821();
C8.M837();
C7.M738();
C6.M644();
C6.M615();
}
public static void M615()
{
C7.M715();
C6.M616();
}
public static void M616()
{
C7.M777();
C6.M679();
C9.M962();
C8.M891();
C6.M638();
C9.M948();
C6.M617();
}
public static void M617()
{
C6.M651();
C6.M697();
C6.M627();
C7.M778();
C9.M969();
C9.M956();
C9.M912();
C6.M618();
}
public static void M618()
{
C9.M930();
C6.M677();
C7.M751();
C9.M979();
C6.M619();
}
public static void M619()
{
C7.M727();
C8.M877();
C6.M666();
C9.M939();
C6.M620();
}
public static void M620()
{
C7.M750();
C7.M757();
C7.M731();
C7.M796();
C6.M672();
C6.M621();
}
public static void M621()
{
C9.M943();
C9.M912();
C6.M622();
}
public static void M622()
{
C6.M614();
C7.M783();
C7.M704();
C7.M752();
C7.M767();
C7.M762();
C7.M787();
C7.M736();
C9.M902();
C6.M623();
}
public static void M623()
{
C6.M603();
C6.M624();
}
public static void M624()
{
C9.M929();
C9.M981();
C6.M625();
}
public static void M625()
{
C9.M905();
C6.M661();
C6.M626();
}
public static void M626()
{
C6.M643();
C9.M977();
C7.M716();
C8.M898();
C6.M614();
C6.M623();
C6.M692();
C6.M627();
}
public static void M627()
{
C7.M792();
C7.M746();
C8.M854();
C6.M625();
C9.M962();
C8.M833();
C6.M657();
C6.M628();
}
public static void M628()
{
C8.M898();
C9.M987();
C8.M827();
C9.M924();
C9.M982();
C8.M817();
C9.M949();
C9.M989();
C9.M974();
C6.M629();
}
public static void M629()
{
C9.M937();
C6.M630();
}
public static void M630()
{
C8.M819();
C7.M774();
C6.M682();
C6.M631();
}
public static void M631()
{
C6.M611();
C7.M771();
C8.M900();
C9.M934();
C8.M874();
C7.M715();
C7.M769();
C6.M632();
}
public static void M632()
{
C6.M660();
C8.M880();
C6.M633();
}
public static void M633()
{
C6.M642();
C8.M881();
C8.M877();
C6.M672();
C7.M768();
C6.M629();
C9.M963();
C6.M683();
C6.M661();
C6.M634();
}
public static void M634()
{
C7.M736();
C9.M908();
C6.M635();
}
public static void M635()
{
C6.M628();
C7.M725();
C9.M923();
C9.M982();
C6.M684();
C9.M977();
C6.M636();
}
public static void M636()
{
C6.M618();
C6.M664();
C6.M637();
}
public static void M637()
{
C6.M615();
C7.M792();
C9.M931();
C7.M721();
C6.M691();
C7.M784();
C8.M818();
C7.M747();
C8.M865();
C6.M638();
}
public static void M638()
{
C8.M846();
C9.M908();
C7.M709();
C6.M639();
}
public static void M639()
{
C9.M957();
C7.M769();
C6.M685();
C6.M640();
}
public static void M640()
{
C6.M692();
C6.M621();
C8.M811();
C8.M874();
C8.M861();
C6.M676();
C6.M641();
}
public static void M641()
{
C7.M750();
C7.M790();
C7.M786();
C9.M995();
C6.M682();
C8.M813();
C9.M951();
C6.M642();
}
public static void M642()
{
C9.M916();
C8.M863();
C8.M879();
C8.M836();
C9.M906();
C8.M873();
C8.M897();
C8.M842();
C9.M931();
C6.M643();
}
public static void M643()
{
C8.M805();
C9.M977();
C7.M719();
C6.M616();
C8.M826();
C6.M625();
C9.M913();
C6.M644();
}
public static void M644()
{
C8.M811();
C9.M925();
C6.M643();
C7.M753();
C7.M739();
C9.M929();
C8.M856();
C6.M645();
}
public static void M645()
{
C9.M940();
C9.M992();
C6.M633();
C7.M750();
C7.M783();
C6.M646();
}
public static void M646()
{
C8.M894();
C9.M930();
C7.M792();
C8.M833();
C6.M679();
C9.M932();
C7.M777();
C6.M647();
}
public static void M647()
{
C7.M793();
C7.M778();
C8.M878();
C6.M605();
C6.M656();
C6.M697();
C7.M788();
C7.M734();
C9.M963();
C6.M648();
}
public static void M648()
{
C6.M682();
C7.M788();
C6.M603();
C6.M627();
C6.M649();
}
public static void M649()
{
C7.M764();
C7.M724();
C9.M948();
C9.M978();
C6.M694();
C9.M932();
C9.M903();
C8.M810();
C6.M650();
}
public static void M650()
{
C6.M687();
C9.M916();
C6.M684();
C7.M787();
C8.M823();
C6.M651();
}
public static void M651()
{
C9.M945();
C9.M980();
C7.M715();
C8.M829();
C7.M732();
C8.M863();
C8.M873();
C7.M735();
C7.M760();
C6.M652();
}
public static void M652()
{
C8.M806();
C6.M653();
}
public static void M653()
{
C8.M870();
C6.M654();
}
public static void M654()
{
C9.M994();
C8.M886();
C6.M655();
}
public static void M655()
{
C9.M995();
C6.M628();
C7.M710();
C7.M730();
C9.M953();
C6.M684();
C6.M650();
C6.M656();
}
public static void M656()
{
C9.M967();
C6.M697();
C9.M917();
C7.M739();
C6.M613();
C6.M602();
C9.M909();
C6.M657();
}
public static void M657()
{
C8.M815();
C7.M701();
C6.M673();
C7.M773();
C8.M893();
C6.M671();
C8.M889();
C9.M987();
C6.M675();
C6.M658();
}
public static void M658()
{
C6.M669();
C7.M726();
C8.M873();
C9.M938();
C7.M714();
C6.M659();
}
public static void M659()
{
C6.M631();
C8.M815();
C7.M790();
C6.M660();
}
public static void M660()
{
C8.M881();
C8.M816();
C6.M628();
C6.M632();
C7.M780();
C6.M661();
}
public static void M661()
{
C8.M895();
C7.M776();
C8.M817();
C7.M734();
C7.M747();
C6.M624();
C6.M662();
}
public static void M662()
{
C6.M659();
C6.M656();
C9.M965();
C9.M921();
C7.M713();
C9.M973();
C9.M925();
C6.M663();
}
public static void M663()
{
C7.M721();
C6.M655();
C7.M734();
C6.M616();
C6.M664();
}
public static void M664()
{
C6.M616();
C6.M630();
C9.M982();
C8.M826();
C7.M709();
C7.M797();
C8.M811();
C7.M714();
C6.M665();
}
public static void M665()
{
C9.M998();
C6.M674();
C6.M642();
C6.M666();
}
public static void M666()
{
C6.M652();
C7.M775();
C7.M714();
C7.M771();
C9.M939();
C6.M672();
C6.M646();
C8.M829();
C8.M815();
C6.M667();
}
public static void M667()
{
C7.M748();
C7.M769();
C9.M916();
C8.M841();
C8.M864();
C6.M658();
C7.M761();
C6.M668();
}
public static void M668()
{
C8.M892();
C6.M616();
C8.M856();
C8.M826();
C6.M669();
}
public static void M669()
{
C7.M793();
C9.M989();
C6.M626();
C9.M949();
C8.M811();
C7.M781();
C6.M670();
}
public static void M670()
{
C6.M656();
C8.M892();
C8.M879();
C7.M720();
C9.M921();
C7.M750();
C6.M625();
C9.M948();
C7.M715();
C6.M671();
}
public static void M671()
{
C9.M969();
C6.M694();
C6.M672();
}
public static void M672()
{
C7.M745();
C8.M835();
C6.M657();
C7.M792();
C9.M954();
C6.M673();
}
public static void M673()
{
C6.M657();
C9.M927();
C8.M838();
C7.M780();
C6.M626();
C7.M736();
C8.M825();
C9.M908();
C6.M674();
}
public static void M674()
{
C7.M780();
C9.M914();
C7.M722();
C8.M833();
C6.M648();
C8.M845();
C8.M827();
C8.M854();
C6.M675();
}
public static void M675()
{
C7.M797();
C9.M919();
C7.M714();
C6.M634();
C8.M811();
C6.M647();
C8.M830();
C6.M676();
}
public static void M676()
{
C7.M763();
C6.M627();
C6.M677();
}
public static void M677()
{
C9.M957();
C9.M933();
C8.M832();
C6.M678();
}
public static void M678()
{
C8.M864();
C7.M725();
C6.M642();
C8.M817();
C7.M712();
C8.M853();
C9.M982();
C6.M697();
C8.M841();
C6.M679();
}
public static void M679()
{
C7.M768();
C7.M799();
C9.M939();
C6.M680();
}
public static void M680()
{
C6.M646();
C9.M953();
C9.M916();
C9.M979();
C6.M681();
}
public static void M681()
{
C9.M994();
C6.M636();
C8.M832();
C6.M624();
C6.M682();
}
public static void M682()
{
C7.M791();
C9.M949();
C9.M979();
C6.M683();
}
public static void M683()
{
C7.M798();
C7.M788();
C9.M961();
C8.M846();
C6.M682();
C7.M727();
C9.M967();
C9.M922();
C8.M804();
C6.M684();
}
public static void M684()
{
C7.M743();
C6.M685();
}
public static void M685()
{
C8.M814();
C6.M686();
}
public static void M686()
{
C8.M872();
C9.M928();
C6.M643();
C8.M846();
C8.M889();
C9.M908();
C6.M687();
}
public static void M687()
{
C6.M673();
C8.M803();
C9.M977();
C6.M688();
}
public static void M688()
{
C8.M837();
C9.M958();
C6.M633();
C7.M702();
C6.M689();
}
public static void M689()
{
C6.M626();
C7.M761();
C8.M873();
C6.M610();
C8.M897();
C6.M654();
C7.M742();
C9.M921();
C6.M690();
}
public static void M690()
{
C8.M813();
C7.M768();
C7.M723();
C6.M691();
}
public static void M691()
{
C9.M906();
C8.M836();
C7.M731();
C7.M780();
C6.M692();
}
public static void M692()
{
C9.M959();
C6.M694();
C6.M674();
C9.M944();
C6.M660();
C6.M693();
}
public static void M693()
{
C8.M855();
C7.M726();
C6.M694();
}
public static void M694()
{
C9.M982();
C6.M680();
C8.M844();
C7.M768();
C9.M935();
C8.M820();
C8.M879();
C9.M983();
C9.M980();
C6.M695();
}
public static void M695()
{
C8.M804();
C9.M924();
C8.M819();
C7.M786();
C6.M696();
}
public static void M696()
{
C7.M730();
C6.M677();
C7.M740();
C6.M697();
}
public static void M697()
{
C9.M922();
C8.M896();
C7.M741();
C6.M636();
C6.M657();
C7.M746();
C6.M672();
C6.M608();
C8.M850();
C6.M698();
}
public static void M698()
{
C7.M702();
C8.M802();
C6.M699();
}
public static void M699()
{
C7.M772();
C6.M669();
C7.M758();
C8.M841();
C6.M700();
}
public static void M700()
{
C6.M646();
C8.M832();
C9.M901();
C8.M868();
C9.M921();
C8.M854();
C9.M968();
C7.M701();
}
}
}
